clear global; clear variables;
%测量次数对定位误差的影响
%load anchor; 
%Anchor = anchor;
%m = length(Anchor);

m = 20;
t = 50;
Target = [250, 250];
sigmaDistance = 5;
sigmaAngle = 0.03;
rsigmaDistance = 5;
rsigmaAngle = 0.03;
w_sigmaDistance = 10;
w_sigmaAngle = 0.06;
q_y_data = 0;
q_x_data = 0;
N = 100;
NN = 10000;
RN = 100;
T=10;
Anchor_quant = zeros(N,2);
Anchor_data = zeros(N,2);
Anchor_x = zeros(1,N);
Anchor_y = zeros(1,N);
Anchor_quant_x = zeros(1,N);
Anchor_quant_y = zeros(1,N);
quant_x = zeros(m,1);
quant_y = zeros(m,1);
Ris0 = ones(1,2);
q_x = zeros(1,m);
q_y = zeros(1,m);
LocationEstimation=zeros(NN,2);
ErrorProposedAlg = ones(NN,1); 
LocationEstimation1=zeros(NN,2);
ErrorProposedAlg1 = ones(NN,1);
LocationEstimation2=zeros(NN,2);
ErrorProposedAlg2 = ones(NN,1);
LocationEstimation3=zeros(NN,2);
ErrorProposedAlg3 = ones(NN,1);
meanerror=ones(T,1);
meanerror1=ones(T,1);
meanerror2=ones(T,1);
meanerror3=zeros(T,1);
for k=1:10
    for i=1:100*k
        Anchor = rand(m,2)*500;
        Ris = rand(1,2)*500;   
        Distance = zeros(m,N);
        Angle = zeros(m,N);
        Rdistance = zeros(1,RN);
        Rangle = zeros(1,RN);
        [Rdistance0,Rangle0] = GetMeasurementForRIS(Ris, Target, rsigmaDistance, rsigmaAngle, RN);
        Rdistance(1,:) = Rdistance0';%1行10000列
        Rangle(1,:) = Rangle0';%1行一百列
        Distance_t = zeros(t-1,N);
        DistanceR = zeros(1,N);
        AngleR = zeros(1,N);
        Angle_t = zeros(t-1,N);
        [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(1,:), Target, sigmaDistance, sigmaAngle, N);
        DistanceR(1,:) = Distance_r';
        AngleR(1,:) = Angle_r';
        Ris0 = RISPPADL_no_noise(Anchor(1,:), DistanceR, AngleR,Rdistance,Rangle,Ris);
        for j = 1:5
        % for each anchor node
        Anchor0 = Anchor(j,:);
        [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, w_sigmaDistance, w_sigmaAngle, N);
        Distance(j,:) = Distance0';
        Angle(j,:) = Angle0';  
        end % now the measurements have been obtained
     for j = 6:m
        % for each anchor node
        Anchor0 = Anchor(j,:);
        [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, N);
        Distance(j,:) = Distance0';
        Angle(j,:) = Angle0';
     end
         LocationEstimation3(i,1) = Ris0(1,1);
        LocationEstimation3(i,2) = Ris0(1,2);
       for d = 1:t
           q_x_data = 0;
           q_y_data = 0;
           if d == 1
           for b = 1:m
               Anchor_data(b,:) = ProposedLocAlgorithm(Anchor(b,:), Distance(b,:), Angle(b,:));
               Anchor_x(1,1) =  Anchor_data(b,1) - Ris0(1,1);
               Anchor_y(1,1) =  Anchor_data(b,2) - Ris0(1,2);
               Anchor_quant_x(1,1) = quantize_cluster(Anchor_x(1,1),3,2,3);
               Anchor_quant_y(1,1) = quantize_cluster(Anchor_y(1,1),3,2,3);
               q_x(1,b) = sum((Anchor_quant_x-Anchor_x).^2,[1,2]);
               q_y(1,b) = sum((Anchor_quant_y-Anchor_y).^2,[1,2]);
               quant_x(b,1) = mean( Anchor_quant_x,[1,2]);
               quant_y(b,1) = mean( Anchor_quant_y,[1,2]);
                q_x_data = q_x_data+(1/q_x(1,b));
                q_y_data = q_y_data+(1/q_y(1,b));
                LocationEstimation3(i,1) = LocationEstimation3(i,1)+((1/q_x(1,b))/q_x_data)*quant_x(b,1);
                LocationEstimation3(i,2) = LocationEstimation3(i,2)+((1/q_y(1,b))/q_y_data)*quant_y(b,1);
           end
           end
           if d >1
               for b = 1:m
                   if b<=5
                       [Distance_quant,Angle_quant] = GetMeasurementForEachAnchor(Anchor(b,:), Target, w_sigmaDistance, w_sigmaAngle, N);
                        Distance_t(d-1,:) = Distance_quant';
                        Angle_t(d-1,:) = Angle_quant';
                          Distance_t = Distance_t(d-1,:);
                         Angle_t = Angle_t(d-1,:);
                          Anchor_data(b,:) = ProposedLocAlgorithm(Anchor(b,:), Distance_t, Angle_t);
                          Anchor_x(1,1) =  Anchor_data(b,1) -  LocationEstimation3(i,1);
                          Anchor_y(1,1) =  Anchor_data(b,2) -  LocationEstimation3(i,2);
                          Anchor_quant_x(1,1) = quantize_cluster(Anchor_x(1,1),3,2,3);
                          Anchor_quant_y(1,1) = quantize_cluster(Anchor_y(1,1),3,2,3);
                          q_x(1,b) = sum((Anchor_quant_x-Anchor_x).^2,[1,2]);
                          q_y(1,b) = sum((Anchor_quant_y-Anchor_y).^2,[1,2]);
                          quant_x(b,1) = mean( Anchor_quant_x,[1,2]);
                          quant_y(b,1) = mean( Anchor_quant_y,[1,2]);
                          q_x_data = q_x_data+(1/q_x(1,b));
                          q_y_data = q_y_data+(1/q_y(1,b));
                          LocationEstimation3(i,1) = LocationEstimation3(i,1)+((1/q_x(1,b))/q_x_data)*quant_x(b,1);
                          LocationEstimation3(i,2) = LocationEstimation3(i,2)+((1/q_y(1,b))/q_y_data)*quant_y(b,1);
                   end
                   if b > 5
                       [Distance_quant,Angle_quant] = GetMeasurementForEachAnchor(Anchor(b,:), Target, sigmaDistance, sigmaAngle, N);
                        Distance_t(d-1,:) = Distance_quant';
                        Angle_t(d-1,:) = Angle_quant';
                          Distance_t = Distance_t(d-1,:);
                          Angle_t = Angle_t(d-1,:);
                          Anchor_data(b,:) = ProposedLocAlgorithm(Anchor(b,:), Distance_t, Angle_t);
                          Anchor_x(1,1) =  Anchor_data(b,1) -  LocationEstimation3(i,1);
                          Anchor_y(1,1) =  Anchor_data(b,2) -  LocationEstimation3(i,2);
                          Anchor_quant_x(1,1) = quantize_cluster(Anchor_x(1,1),3,2,3);
                          Anchor_quant_y(1,1) = quantize_cluster(Anchor_y(1,1),3,2,3);
                          q_x(1,b) = sum((Anchor_quant_x-Anchor_x).^2,[1,2]);
                          q_y(1,b) = sum((Anchor_quant_y-Anchor_y).^2,[1,2]);
                          quant_x(b,1) = mean( Anchor_quant_x,[1,2]);
                          quant_y(b,1) = mean( Anchor_quant_y,[1,2]);
                          q_x_data = q_x_data+(1/q_x(1,b));
                          q_y_data = q_y_data+(1/q_y(1,b));
                          LocationEstimation3(i,1) = LocationEstimation3(i,1)+((1/q_x(1,b))/q_x_data)*quant_x(b,1);
                          LocationEstimation3(i,2) = LocationEstimation3(i,2)+((1/q_y(1,b))/q_y_data)*quant_y(b,1);
                   end
               end
           end
       end
        %Anchor_data(1,:) = ProposedLocAlgorithm(CurrentAnchor(j,:), CurrentDistance_t, CurrentAngle_t);
      
        ErrorProposedAlg3(i,:) = sqrt((Target(1,1) - LocationEstimation3(i,1))^2 + (Target(1,2) - LocationEstimation3(i,2))^2);
     
        if i >= 3
            [TargetTemp] = ExistingLocAlgorithm(Anchor,Distance);
            LocationEstimation(i,:) = TargetTemp;
            ErrorProposedAlg(i,1) = sqrt((Target(1,1) - TargetTemp(1,1))^2 + (Target(1,2) - TargetTemp(1,2))^2);
        end
        [TargetTemp1] = RISPPADL(Anchor, Distance,Angle,Rdistance, Rangle, Ris);
        LocationEstimation1(i,:) = TargetTemp1;
        ErrorProposedAlg1(i,:)= sqrt((Target(1,1) - TargetTemp1(1,1))^2 + (Target(1,2) - TargetTemp1(1,2))^2);

        [TargetTemp2] = PPProposedLocAlgorithm(Anchor, Distance, Angle);
        LocationEstimation2(i,:) = TargetTemp2;
        ErrorProposedAlg2(i,:)= sqrt((Target(1,1) - TargetTemp2(1,1))^2 + (Target(1,2) - TargetTemp2(1,2))^2);
        % next how to record the results for 1000 runs; we can only record the
        % errors 
    end
    meanerror(k,:)=mean(ErrorProposedAlg);
    meanerror1(k,:)=mean(ErrorProposedAlg1);
    meanerror2(k,:)=mean(ErrorProposedAlg2);
    meanerror3(k,:)=mean(ErrorProposedAlg3);
end
figure(1);
plot((1000:1000:NN),meanerror,'r-o','MarkerSize',8,'LineWidth',1.5)
hold on
plot((1000:1000:NN),meanerror1,'g-x','MarkerSize',8,'LineWidth',1.5)
hold on
plot((1000:1000:NN),meanerror2,'b-*','MarkerSize',8,'LineWidth',1.5)
hold on
plot((1000:1000:NN),meanerror3,'m-*','MarkerSize',8,'LineWidth',1.5)

%ylim([0,1]);

legend('\fontsize{14} TML','\fontsize{14} RPPL','\fontsize{14} PPADL','\fontsize{14}ours');
xlabel({'Number of Measurements '},'FontSize',14);
ylabel({'Location Error (meters)'},'FontSize',14);