clear global; clear variables;
%Target = 250;
Anchor = rand(5,1);

%Anchor1 = zeros(1,5);
%q_data = ones(1,5);


%for i = 1:5    
%data(1,i) = Anchor(1,i)-Target;
[Anchor1,q_data]= quantize_clipping(Anchor,5,'SQE');

%end
%%SQE

%%expectation
% q = max(q_data);