clear all;
load('RealDATA.mat')
plot(RealDATA(:,1),RealDATA(:,2),'go','LineWidth',1,'MarkerEdgeColor','k','MarkerFaceColor','b','MarkerSize',10)
hold on
plot(50,50,'cs','LineWidth',1,'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',12)
hold on
axis([0 100 0 100])
grid on;
set(gca,'GridLineStyle',':','GridColor','k','GridAlpha',1);
xlabel({'X'},'FontSize',12);
ylabel({'Y'},'FontSize',12);
T=legend('\fontsize{12} Anchor node','\fontsize{12} Target node');
hold off