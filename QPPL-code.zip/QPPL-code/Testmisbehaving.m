clear global; clear variables;
m = 30;
Target = [50, 50];
sigmaDistance = 2;
sigmaAngle = 0.01;
sigmaDistance0 =10;
sigmaAngle0 = 0.1;
sigmaDistance1 =2;
sigmaAngle1 = 0.01;
N = 100; % the number of the measurements
NN = 50; % the number of runs to reduce the randomness
Error1 = zeros(5,NN);
Error2 = zeros(5,NN);
Error3 = zeros(5,NN);
Error4 = zeros(5,NN);
Error5 = zeros(5,NN);
R = 30;
%Anchorr1 = zeros(R,1);
%Anchorr2 = zeros(R,1);
Anchorx = zeros(R,1);
Anchory = zeros(R,1);
     LocationEstimation4 = zeros(m/3,2);
    ErrorProposedAlg4 = zeros(5,1); 


    Anchor = rand(m,2)*100;
    Distance = zeros(m,NN);
    Angle = zeros(m,NN);
    Distance_w = zeros(1,NN);
    Angle_w = zeros(1,NN);
               ErrorProposedAlg1 = zeros(5,1);
           LocationEstimation2 = zeros(5,2);
           ErrorProposedAlg2 = zeros(5,1); 
    
           LocationEstimation3 = zeros(5,2);
           ErrorProposedAlg3 = zeros(5,1); 
for i = 1:NN
    for k = 1:5
      
         

            %ErrorProposedAlg5 = zeros(m/3,1);

    for n = 1:m
        Anchor0 = Anchor(n,:);
        if n<k*3+1
            [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance0, sigmaAngle0, NN);
        else
           [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, NN);
        end
       Distance(n,:) = Distance0';
       Angle(n,:) = Angle0';
    end
    
          Anchor_data = zeros(m,2);
          Anchor_quant_x = zeros(1,m);
          Anchor_quant_y = zeros(1,m);
          
          Anchorx1 = zeros(1,m);
          Anchory1 = zeros(1,m);
          q_data_x = zeros(1,m); 
          q_data_y = zeros(1,m);
          Anchor_x = zeros(m,20);
          Anchor_y = zeros(m,20);
          LocationEstimation1 = zeros(10,2);
          %LocationEstimation5 = zeros(10,2);
          %CurrentAnchor = Anchor(1:m,:);
          %CurrentDistance = Distance(1:m,:);
          %CurrentAngle = Angle(1:j*3,:);
          for t = 1:10
               q_x = 0;
               q_y = 0;
                for q = 1:m
                 for r = 1:R
                  if q<k*3+1
                           [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance0, sigmaAngle0, NN);
                  else                                                                                 
                            [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
                  end
                      Distance_w(1,:) = distance_w';
                      Angle_w(1,:) = angle_w';
                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance_w(1,:), Angle_w(1,:));
                   if t == 1 
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(1,2);
                   end
                 
                   if t > 1
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(t-1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(t-1,2);
                   end
                 end
                  % Anchor_x(q,t) = mean(Anchorx);
                  % Anchor_y(q,t) = mean(Anchory);
                   if q<=0.2*m
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,5,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,5,'SQE');
                   else
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,3,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,3,'SQE');
                   end
                  % Anchorr1 = Anchorr1';
                  % Anchorr2 = Anchorr2';
                   Anchor_quant_x(1,q) = mean(Anchorr1);
                   Anchor_quant_y(1,q) = mean(Anchorr2);
                    q_x = q_x + 1/q_data_x(1,q);
                    q_y = q_y + 1/q_data_y(1,q);
                   % Anchorx = Anchorx';
                    %Anchory = Anchory';

                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance_w(1,:), Angle_w(1,:));
%                    Anchorx1(1,q) = Anchor_data(q,1) - LocationEstimation5(1,1);
 %                   Anchory1(1,q) = Anchor_data(q,2) - LocationEstimation5(1,2);
                end
                if t == 1
                   for q = 1:m
                      LocationEstimation1(1,1) = LocationEstimation1(1,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                      LocationEstimation1(1,2) = LocationEstimation1(1,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                     % LocationEstimation5(1,1) = LocationEstimation5(1,1)+ Anchorx1(1,q) * 1/(j*3);
                     % LocationEstimation5(1,2) = LocationEstimation5(1,2)+ Anchory1(1,q) * 1/(j*3);
                   end
                end
                if t > 1
                     LocationEstimation1(t,1) = LocationEstimation1(t-1,1);
                     LocationEstimation1(t,2) = LocationEstimation1(t-1,2);
                    % LocationEstimation5(t,1) = LocationEstimation5(t-1,1);
                    % LocationEstimation5(t,2) = LocationEstimation5(t-1,2);
                    for q = 1:m
                         LocationEstimation1(t,1) = LocationEstimation1(t,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                         LocationEstimation1(t,2) = LocationEstimation1(t,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                    % LocationEstimation5(t,1) = LocationEstimation5(t,1)+ Anchorx1(1,q) * 1/(j*3);
                     % LocationEstimation5(t,2) = LocationEstimation5(t,2)+ Anchory1(1,q) * 1/(j*3);
                    end
                end
          end
           ErrorProposedAlg1(k,:) = sqrt((Target(1,1) - LocationEstimation1(t,1))^2 + (Target(1,2) - LocationEstimation1(t,2))^2);
          % ErrorProposedAlg5(j,:) = sqrt((Target(1,1) - LocationEstimation5(t,1))^2 + (Target(1,2) - LocationEstimation5(t,2))^2);
           
           %PPADL
         
             [TargetTemp2] = PPProposedLocAlgorithm(Anchor, Distance, Angle);
             LocationEstimation2(k,:) = TargetTemp2;
             ErrorProposedAlg2(k,1) = sqrt((Target(1,1) - TargetTemp2(1,1))^2 + (Target(1,2) - TargetTemp2(1,2))^2);
           
           
           %Gaussian
           [TargetTemp3] = GPPADL(Anchor, Distance, Angle);
            LocationEstimation3(k,:) = TargetTemp3;
            ErrorProposedAlg3(k,1) = sqrt((Target(1,1) - TargetTemp3(1,1))^2 + (Target(1,2) - TargetTemp3(1,2))^2); 
            
             [TargetTemp4] = PPProposedLocAlgorithm(Anchor, Distance, Angle);
             LocationEstimation4(k,:) = TargetTemp4;
             ErrorProposedAlg4(k,1) = sqrt((Target(1,1) - TargetTemp4(1,1))^2 + (Target(1,2) - TargetTemp4(1,2))^2);
        
    end
         Error1(:,i) = ErrorProposedAlg1(:,1);
         Error2(:,i) = ErrorProposedAlg2(:,1);
         Error3(:,i) = ErrorProposedAlg3(:,1);
         Error4(:,i) = ErrorProposedAlg4(:,1);
        %Error5(:,i) = ErrorProposedAlg5(:,1);
 
end

AnchorNum1 = (3:3:m);
AnchorNum2 = (2:2:m);
AnchorNum3 = (2:2:m);
AnchorNum4 = (2:2:m);

Error1 = Error1';
Err1 = mean(Error1);

Error2 = Error2';
Err2 = mean(Error2);

Error3 = Error3';
Err3 = mean(Error3);

Error4 = Error4';
Err4 = mean(Error4);
Error5 = Error5';
Err5 = mean(Error5);
%Err2(1,1)=NaN;
figure(1);
set(gca,'xtick',(3:3:30));
plot((3:3:15),Err1,'r-o','MarkerSize',8,'LineWidth',1.5)  
hold on
plot((3:3:15),Err2,'k-s','MarkerSize',8,'LineWidth',1.5)
hold on
plot((3:3:15),Err4,'c-+','MarkerSize',8,'LineWidth',1.5)
hold on
plot((3:3:15),Err3,'g->','MarkerSize',8,'LineWidth',1.5)
%plot((3:3:30),Err5,'m->','MarkerSize',8,'LineWidth',1.5)
set(gca,'xtick',(3:3:15));
xlim([3, 15]);
%set(gca,'xtick',3:2:20);
legend('\fontsize{15} QPPL','\fontsize{15} HPPL','\fontsize{15} ZPPL','\fontsize{15} GPPL')
xlabel({'恶意节点数量'},'FontSize',14);
ylabel({'定位误差（米）'},'FontSize',14);
hold off

