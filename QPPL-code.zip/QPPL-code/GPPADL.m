function [TargetEstimated] = GPPADL(Anchor, Distance, Angle)
%PPPROPOSEDLOCALGORITHM 此处显示有关此函数的摘要
%% setup
[m,~] = size(Anchor); % the number of the anchor nodes is m;%个数
[m1,N] = size(Distance); % the number of the measurements is N;%个数
[m2,N1] = size(Angle);

% test the setup
if m1 ~= m
    error('Error! Something is wrong on the distance ranging with the number of anchor ndoes!');
end

if m2 ~= m
    error('Error! Something is wrong on the angle ranging with the number of anchor node!');
end

if N ~= N1
    error('Error! The numbers of the distance measurements and the angle measurements should be equal!');
end

%% the main part
Target = zeros(m,2); % each anchor will have an estimation%m行2列0矩阵
arr=Gaussian(m,0.05,0.04);%计算噪声
for i = 1:m
    % first get the anchor and its measurements
    Anchor0 = Anchor(i,:);%i，：取行操作 
    Distance0 = Distance(i,:);
    Angle0 = Angle(i,:);

    % get the mean of the measurements
    d = mean(Distance0); a = mean(Angle0);
    % get the estimated result for anchor0
    Target(i,:) = SingleAnchorLocModel(a, d, Anchor0)+arr(1,i);
end

x = mean(Target(:,1));
y = mean(Target(:,2));
%TargetEstimated = mean(Target);
TargetEstimated = [x,y];

end

