clear global; clear variables;
%真实数据实验
%load anchor; 
%Anchor = anchor;
%m = length(Anchor);
Target = [50, 50];
m = 30;
N = 10;
NN = 10;
h=150;
Distance = zeros(1,NN);
Angle = zeros(1,NN);
b = 30;
sigmaDistance = 3;
sigmaAngle = 0.03;
sigmaDistance1 = 5;
sigmaAngle1 = 0.1;
%LocationEstimation = zeros(N,2);
ErrorProposedAlg = zeros(10,1);
%LocationEstimation1 = zeros(N,2);
ErrorProposedAlg1 = zeros(10,1);
%LocationEstimation2 = zeros(N,2);
ErrorProposedAlg2 = zeros(10,1);
%LocationEstimation3 = zeros(N,2);
ErrorProposedAlg3 = zeros(10,1);
Anchor_data = zeros(m,2);
Anchor_data1 = zeros(h,2);
Anchor_data2 = zeros(m,2);
Anchor_data3 = zeros(h,2);
Anchor_quant_x = zeros(1,m);
Anchor_quant_y = zeros(1,m);
Anchor_quant_x1 = zeros(1,h);
Anchor_quant_y1 = zeros(1,h);
Anchor_quant_x2 = zeros(1,m);
Anchor_quant_y2 = zeros(1,m);
Anchor_quant_x3 = zeros(1,h);
Anchor_quant_y3 = zeros(1,h);
q_data_x = zeros(1,m);
q_data_y = zeros(1,m);
q_data_x1 = zeros(1,h);
q_data_y1 = zeros(1,h);
q_data_x2 = zeros(1,m);
q_data_y2 = zeros(1,m);
q_data_x3 = zeros(1,h);
q_data_y3 = zeros(1,h);
Anchor_x = zeros(m,10);
Anchor_y = zeros(m,10);
Anchor_x1 = zeros(h,10);
Anchor_y1 = zeros(h,10);
Anchor_x2 = zeros(m,10);
Anchor_y2 = zeros(m,10);
Anchor_x3 = zeros(h,10);
Anchor_y3 = zeros(h,10);
meanerror=zeros(10,1);
meanerror1=zeros(10,1);
meanerror2=zeros(10,1);
meanerror3=zeros(10,1);
Error = zeros(10,N);
Error1 = zeros(10,N);
Error2 = zeros(10,N);
Error3 = zeros(10,N);
for a = 1:N
    Anchor = rand(h,2)*100;
    LocationEstimation = zeros(10,2);
    LocationEstimation1 = zeros(10,2);
    LocationEstimation2 = zeros(10,2);
    LocationEstimation3 = zeros(10,2);
    m = 30;
    b = 30;
    d = 30;
    c = 30;
for k = 1:10
   for i = 1*k
      % P = 0;
        q_x = 0;
        q_y = 0;
        q_x1 = 0;
        q_y1 = 0;
        q_x2 = 0;
        q_y2 = 0;
        q_x3 = 0;
        q_y3 = 0;
        for q = 1:m
        [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
        Distance(1,:) = Distance_r';
        Angle(1,:) = Angle_r';
        Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance(1,:), Angle(1,:));
         if i == 1 
          Anchor_x(q,i) =  Anchor_data(q,1) - LocationEstimation(1,1);
          Anchor_y(q,i) =  Anchor_data(q,2) - LocationEstimation(1,2);
         end
         if i > 1
          Anchor_x(q,i) =  Anchor_data(q,1) - LocationEstimation(i-1,1);
          Anchor_y (q,i)=  Anchor_data(q,2) - LocationEstimation(i-1,2);
         end
         %bit=4
         if q<=0.3*m
                    [Anchor_quant_x(1,q),q_data_x(1,q)] = quantize_clipping(Anchor_x(q,i),3,'SQE');
                    [Anchor_quant_y(1,q),q_data_y(1,q)] = quantize_clipping(Anchor_y(q,i),3,'SQE');
         else
                    [Anchor_quant_x(1,q),q_data_x(1,q)] = quantize_clipping(Anchor_x(q,i),8,'SQE');
                    [Anchor_quant_y(1,q),q_data_y(1,q)] = quantize_clipping(Anchor_y(q,i),8,'SQE');
         end
          q_x = q_x + 1/q_data_x(1,q);
          q_y = q_y + 1/q_data_y(1,q);
        end
        
        if i == 1
            for q = 1:m
                LocationEstimation(1,1) = LocationEstimation(1,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                LocationEstimation(1,2) = LocationEstimation(1,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
            end  
        end
        if i > 1
            LocationEstimation(i,1) = LocationEstimation(i-1,1);
            LocationEstimation(i,2) = LocationEstimation(i-1,2);
             for q = 1:m
                LocationEstimation(i,1) = LocationEstimation(i,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                LocationEstimation(i,2) = LocationEstimation(i,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
            end  
        end
        ErrorProposedAlg(i,:) = sqrt((Target(1,1) - LocationEstimation(i,1))^2 + (Target(1,2) - LocationEstimation(i,2))^2);
   
        
        for q = 1:b
        [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
        Distance(1,:) = Distance_r';
        Angle(1,:) = Angle_r';
        Anchor_data1(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance(1,:), Angle(1,:));
         if i == 1 
          Anchor_x1(q,i) =  Anchor_data1(q,1) - LocationEstimation1(1,1);
          Anchor_y1(q,i) =  Anchor_data1(q,2) - LocationEstimation1(1,2);
         end
         if i > 1
          Anchor_x1(q,i) =  Anchor_data1(q,1) - LocationEstimation1(i-1,1);
          Anchor_y1(q,i)=  Anchor_data1(q,2) - LocationEstimation1(i-1,2);
         end
         %bit=4
         if q<=0.3*b
                    [Anchor_quant_x1(1,q),q_data_x1(1,q)] = quantize_clipping(Anchor_x1(q,i),3,'SQE');
                    [Anchor_quant_y1(1,q),q_data_y1(1,q)] = quantize_clipping(Anchor_y1(q,i),3,'SQE');
         else
                    [Anchor_quant_x1(1,q),q_data_x1(1,q)] = quantize_clipping(Anchor_x1(q,i),8,'SQE');
                    [Anchor_quant_y1(1,q),q_data_y1(1,q)] = quantize_clipping(Anchor_y1(q,i),8,'SQE');
         end
          q_x1 = q_x1 + 1/q_data_x1(1,q);
          q_y1 = q_y1 + 1/q_data_y1(1,q);
        end
        
        if i == 1
            for q = 1:b
                LocationEstimation1(1,1) = LocationEstimation1(1,1)+Anchor_quant_x1(1,q) * ((1/q_data_x1(1,q)) / q_x1);
                LocationEstimation1(1,2) = LocationEstimation1(1,2)+Anchor_quant_y1(1,q) * ((1/q_data_y1(1,q)) / q_y1);
            end  
        end
        if i > 1
            LocationEstimation1(i,1) = LocationEstimation1(i-1,1);
            LocationEstimation1(i,2) = LocationEstimation1(i-1,2);
             for q = 1:b
                LocationEstimation1(i,1) = LocationEstimation1(i,1)+Anchor_quant_x1(1,q) * ((1/q_data_x1(1,q)) / q_x1);
                LocationEstimation1(i,2) = LocationEstimation1(i,2)+Anchor_quant_y1(1,q) * ((1/q_data_y1(1,q)) / q_y1);
            end  
        end
        
        for q = 1:d
        [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
        Distance(1,:) = Distance_r';
        Angle(1,:) = Angle_r';
        Anchor_data2(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance(1,:), Angle(1,:));
         if i == 1 
          Anchor_x2(q,i) =  Anchor_data2(q,1) - LocationEstimation2(1,1);
          Anchor_y2(q,i) =  Anchor_data2(q,2) - LocationEstimation2(1,2);
         end
         if i > 1
          Anchor_x2(q,i) =  Anchor_data2(q,1) - LocationEstimation2(i-1,1);
          Anchor_y2(q,i)=  Anchor_data2(q,2) - LocationEstimation2(i-1,2);
         end
         %bit=4
         if q<=0.3*d
                    [Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),3,'SQE');
                    [Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),3,'SQE');
         else
                    [Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),8,'SQE');
                    [Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),8,'SQE');
         end
          q_x2 = q_x2 + 1/q_data_x2(1,q);
          q_y2 = q_y2 + 1/q_data_y2(1,q);
        end
        
        if i == 1
            for q = 1:d
                LocationEstimation2(1,1) = LocationEstimation2(1,1)+Anchor_quant_x2(1,q) * ((1/q_data_x2(1,q)) / q_x2);
                LocationEstimation2(1,2) = LocationEstimation2(1,2)+Anchor_quant_y2(1,q) * ((1/q_data_y2(1,q)) / q_y2);
            end  
        end
        if i > 1
            LocationEstimation2(i,1) = LocationEstimation2(i-1,1);
            LocationEstimation2(i,2) = LocationEstimation2(i-1,2);
             for q = 1:d
                LocationEstimation2(i,1) = LocationEstimation2(i,1)+Anchor_quant_x2(1,q) * ((1/q_data_x2(1,q)) / q_x2);
                LocationEstimation2(i,2) = LocationEstimation2(i,2)+Anchor_quant_y2(1,q) * ((1/q_data_y2(1,q)) / q_y2);
            end  
        end
        
        
        for q = 1:c
        [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
        Distance(1,:) = Distance_r';
        Angle(1,:) = Angle_r';
        Anchor_data3(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance(1,:), Angle(1,:));
         if i == 1 
          Anchor_x3(q,i) =  Anchor_data3(q,1) - LocationEstimation3(1,1);
          Anchor_y3(q,i) =  Anchor_data3(q,2) - LocationEstimation3(1,2);
         end
         if i > 1
          Anchor_x3(q,i) =  Anchor_data3(q,1) - LocationEstimation3(i-1,1);
          Anchor_y3(q,i)=  Anchor_data3(q,2) - LocationEstimation3(i-1,2);
         end
         %bit=4
         if q<=0.3*c
                    [Anchor_quant_x3(1,q),q_data_x3(1,q)] = quantize_clipping(Anchor_x3(q,i),3,'SQE');
                    [Anchor_quant_y3(1,q),q_data_y3(1,q)] = quantize_clipping(Anchor_y3(q,i),3,'SQE');
         else
                    [Anchor_quant_x3(1,q),q_data_x3(1,q)] = quantize_clipping(Anchor_x3(q,i),8,'SQE');
                    [Anchor_quant_y3(1,q),q_data_y3(1,q)] = quantize_clipping(Anchor_y3(q,i),8,'SQE');
         end
          q_x3 = q_x3 + 1/q_data_x3(1,q);
          q_y3 = q_y3 + 1/q_data_y3(1,q);
        end
        
        if i == 1
            for q = 1:c
                LocationEstimation3(1,1) = LocationEstimation3(1,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
                LocationEstimation3(1,2) = LocationEstimation3(1,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
            end  
        end
        if i > 1
            LocationEstimation3(i,1) = LocationEstimation3(i-1,1);
            LocationEstimation3(i,2) = LocationEstimation3(i-1,2);
             for q = 1:c
                LocationEstimation3(i,1) = LocationEstimation3(i,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
                LocationEstimation3(i,2) = LocationEstimation3(i,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
            end  
        end
        
        
        ErrorProposedAlg(i,:) = sqrt((Target(1,1) - LocationEstimation(i,1))^2 + (Target(1,2) - LocationEstimation(i,2))^2);
        ErrorProposedAlg1(i,:) = sqrt((Target(1,1) - LocationEstimation1(i,1))^2 + (Target(1,2) - LocationEstimation1(i,2))^2);
         ErrorProposedAlg2(i,:) = sqrt((Target(1,1) - LocationEstimation2(i,1))^2 + (Target(1,2) - LocationEstimation2(i,2))^2);
        ErrorProposedAlg3(i,:) = sqrt((Target(1,1) - LocationEstimation3(i,1))^2 + (Target(1,2) - LocationEstimation3(i,2))^2);
   end
      %if k == 1
      m = m - 1;
      b = b + 1;
      d = d - 2;
      c = c + 2;
      %end
      meanerror(k,:)=ErrorProposedAlg(i,:);
      meanerror1(k,:)=ErrorProposedAlg1(i,:);
      meanerror2(k,:)=ErrorProposedAlg2(i,:);
      meanerror3(k,:)=ErrorProposedAlg3(i,:);
end
     Error(:,a) = meanerror(:,1);
     Error1(:,a) = meanerror1(:,1);
     Error2(:,a) = meanerror2(:,1);
     Error3(:,a) = meanerror3(:,1);
end

Error = Error';
Error1 = Error1';
Error2 = Error2';
Error3 = Error3';
Err = mean(Error);
Err1 = mean(Error1);
Err2 = mean(Error2);
Err3 = mean(Error3);



figure(1);
hold on
%plot((2:2:20),Err,'color','#E58579','MarkerSize',10,'LineWidth',2,'Marker','o')
%plot((2:2:20),Err1,'color','#8064a2','MarkerSize',10,'LineWidth',2,'Marker','s')
%plot((2:2:20),Err2,'color','#E1C855','MarkerSize',10,'LineWidth',2,'Marker','x')
plot((1:1:10),Err3,'r-d','MarkerSize',8,'LineWidth',1.5);
plot((1:1:10),Err1,'m-d','MarkerSize',8,'LineWidth',1.5);
plot((1:1:10),Err,'g-d','MarkerSize',8,'LineWidth',1.5);
plot((1:1:10),Err2,'c-d','MarkerSize',8,'LineWidth',1.5);
hold off
 
% 或者设置Y轴为对数坐标
set(gca, 'YScale', 'log');
legend('\fontsize{15} New anchors:20','\fontsize{15} New anchors:10','\fontsize{15}  Failed anchors:10','\fontsize{15}  Failed anchors:20');
xlabel({'Iterations '},'FontSize',14);
ylabel({'Localization Error (meters)'},'FontSize',14);
