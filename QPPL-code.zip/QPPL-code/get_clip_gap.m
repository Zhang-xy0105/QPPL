function [wi, q] = get_clip_gap(data, gap, bits, q_cal)
    % 将输入数据形状重塑为一维数组
    data_shape = size(data);
    data = reshape(data, 1, []);

    % 计算量化级别的数量
    n_clip = 2^bits;

    % 计算每个量化级别的边界
    bound = ((0:n_clip-1) - n_clip/2) * gap + gap / 2;

    % 创建输入数据的深层副本
    wi = data;

    % 将值裁剪到量化边界内
    wi(wi < bound(1)) = bound(1);
    wi(wi >= bound(end)) = bound(end);

    % 量化过程
    for i = 1:n_clip - 1
        left = bound(i);
        right = bound(i + 1);

        % 创建当前量化范围内值的掩码
        mask = (data >= left) & (data < right);
        tmp = data(mask);

        % 检查当前量化范围内是否有值
        if isempty(tmp)
            continue;
        end

        % 将范围内的值归一化到 [0, 1]
        if left ~= right
            tmp = (tmp - left) / (right - left);
        else
            tmp = ones(size(tmp));
        end

        % 根据所选方法计算量化误差
        if strcmp(q_cal, 'expectation')
            p40 = 1 - mod(tmp, 1);
            p41 = mod(tmp, 1);
            q_n0 = floor(i) * gap + min(data);
            q_n1 = ceil(i) * gap + min(data);
            eq = (q_n0 - data).^2 .* p40 + (q_n1 - data).^2 .* p41;
            q = max(eq ./ data.^2);
        end

        % 在原始数组中更新量化值
        tmp = floor(tmp);
        wi(mask) = tmp * (right - left) + left;
    end

    % 计算'SQE'方法的量化误差
    if strcmp(q_cal, 'SQE')
        q = sum((data - wi).^2);
    end

    % 将量化后的数组形状重塑为原始形状
    wi = reshape(wi, data_shape);
end