function [quant_data, q] = quantize_kmeans(data,bits,q_cal)
    n_clusters = 2^bits - 1;
    data_shape = size(data);
    weight = reshape(double(gather(data)), [], 1);
    original_data = data;

    if size(weight, 1) > n_clusters
        [~, label_pred] = kmeans(weight, n_clusters);
        bound = zeros(1, n_clusters);
        all_min = zeros(1, n_clusters);

        for k = 1:n_clusters
            tmp = weight(label_pred == k);
            if isempty(tmp)
                continue;
            end
            all_min(k) = min(tmp);
        end

        [~, index] = sort(all_min);
        cnt = 0;
        last_max = 0;

        for k = index
            tmp = weight(label_pred == k);
            if isempty(tmp)
                continue;
            end
            bound(cnt + 1) = min(tmp);
            last_max = max(tmp);
            cnt = cnt + 1;
        end

        bound(cnt + 1) = last_max;
        cnt = 0;

        for k = index
            original_tmp = reshape(weight(label_pred == k), [], 1);
            tmp = reshape(weight(label_pred == k), [], 1);

            if isempty(tmp)
                continue;
            end

            k_max = bound(cnt + 2);
            k_min = bound(cnt + 1);
            cnt = cnt + 1;

            if k_min ~= k_max
                p_min = (k_max - tmp) / (k_max - k_min);
            else
                p_min = 1;
            end

            prob = rand(size(tmp));

            tmp(prob < p_min) = k_min;
            tmp(prob >= p_min) = k_max;

            weight(label_pred == k) = tmp;

            if strcmp(q_cal, 'expectation')
                q = max(q, max((original_tmp - tmp).^2 ./ original_tmp));
            end
        end
    end

    quant_data = reshape(weight, data_shape);

    if strcmp(q_cal, 'SQE')
        q = sum((original_data - quant_data).^2);
    else
        q = q / original_data.^2;
    end
end