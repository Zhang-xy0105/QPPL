% test the proposed localization algorithm using simulations; the algorithm
% is based on the single anchor localization model
% guanghui wang, October 7, 2018
%锚节点数目对定位误差的影响
clear global; clear variables;
%% setup

% we also need to randomly choose the anchor nodes
%load anchor; 
%Anchor = anchor;
%m = length(Anchor); % number of anchors;
m = 20;
Target = [250, 250]; % target coordinate;
t = 50;
% gaussian ranging error deviation
sigmaDistance = 5;
sigmaAngle = 0.03;
w_sigmaDistance = 20;
w_sigmaAngle = 0.12;
rsigmaDistance = 2;
rsigmaAngle = 0.01;
N = 100; % the number of the measurements
NN = 5000; % the number of runs to reduce the randomness
RN = 100;
%% test the algorithm with the increment of the number of anchor nodes
% anchor number: 1 -- 20
q_y_data = 0;
q_x_data = 0;

Error = ones(m,NN);
Error1 = ones(m-2,NN);
Error2 = ones(m-3,NN);
Error3 = ones(m,NN);
Error4 = ones(m,NN);
Anchor_quant = zeros(N,2);
Anchor_data = zeros(N,2);
Anchor_x = zeros(1,N);
Anchor_y = zeros(1,N);
Anchor_quant_x = zeros(1,N);
Anchor_quant_y = zeros(1,N);
quant_x = zeros(m,1);
quant_y = zeros(m,1);
Ris0 = ones(1,2);
q_x = zeros(1,m);
q_y = zeros(1,m);
for i = 1:NN % for each run
    LocationEstimation = zeros(m,2);
    ErrorProposedAlg = ones(m,1); 
    
    LocationEstimation1 = zeros(m,2);
    ErrorProposedAlg1 = ones(m,1); 
    
    LocationEstimation2 = zeros(m,2);
    ErrorProposedAlg2 = ones(m,1); 
    
    LocationEstimation3 = zeros(m,2);
    ErrorProposedAlg3 = ones(m,1); 
    LocationEstimation4 = zeros(m,2);
    ErrorProposedAlg4 =zeros(m,1); 
    Anchor = rand(m,2)*500;
    Ris = rand(1,2)*500;
    % first get the measurement for each anchor node
    Distance = zeros(m,N);
     Distance_t = zeros(t-1,N);
    DistanceR = zeros(1,N);
    AngleR = zeros(1,N);
    Angle = zeros(m,N);
    Angle_t = zeros(t-1,N);
    Rdistance = zeros(1,RN);
        Rangle = zeros(1,RN);
        [Rdistance0,Rangle0] = GetMeasurementForRIS(Ris, Target, rsigmaDistance, rsigmaAngle, RN);
        Rdistance(1,:) = Rdistance0';%1行10000列
        Rangle(1,:) = Rangle0';%1行一百列
     [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(1,:), Target, sigmaDistance, sigmaAngle, N);
        DistanceR(1,:) = Distance_r';
        AngleR(1,:) = Angle_r';
     Ris0 = RISPPADL_no_noise(Anchor(1,:), DistanceR, AngleR,Rdistance,Rangle,Ris);
    for j = 1:5
        % for each anchor node
      Anchor0 = Anchor(j,:);
        [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, w_sigmaDistance, w_sigmaAngle, N);
        Distance(j,:) = Distance0';
        Angle(j,:) = Angle0';
        % Ris0 = RISPPADL_no_noise(Anchor(1,:), Distance(1,:), Angle(1,:),Rdistance,Rangle,Ris);
       % for k = 1:100
         %Anchor_data(k,:) = ProposedLocAlgorithm(Anchor(j,:), Distance(j,k), Angle(j,k));
         %Anchor_x(1,k) =  Anchor_data(k,1) - Ris0(1,1);
         %Anchor_y(1,k) =  Anchor_data(k,2) - Ris0(1,2);
         %Anchor_quant_x(1,k) = quantize_cluster(Anchor_x(1,k),4,2,2);
       %  Anchor_quant_y(1,k) = quantize_cluster(Anchor_y(1,k),4,2,2);
       % end
       % q_x(1,m) = sum((Anchor_x-Anchor_quant_x).^2);
       %  q_y(1,m) = sum((Anchor_y-Anchor_quant_y).^2);
        % quant_x(m,1) = mean( Anchor_quant_x);
         %quant_y(m,1) = mean( Anchor_quant_y);
    end % now the measurements have been obtained
     for j = 6:m
        % for each anchor node
         Anchor0 = Anchor(j,:);
        [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, N);
        Distance(j,:) = Distance0';
        Angle(j,:) = Angle0';
     end
    
    % next, calculate the localization result using the proposed algorithm
    for j = 1:m
         weight = rand(j,2);
        CurrentAnchor = Anchor(1:j,:);
        CurrentDistance = Distance(1:j,:);
        CurrentAngle = Angle(1:j,:);
        %weight
         LocationEstimation4(j,1) = Ris0(1,1);
        LocationEstimation4(j,2) = Ris0(1,2);
                 LocationEstimation3(j,1) = Ris0(1,1);
        LocationEstimation3(j,2) = Ris0(1,2);
       for k = 1:t
           q_x_data = 0;
           q_y_data = 0;
           if k == 1
           for b = 1:j
               Anchor_data(b,:) = ProposedLocAlgorithm(CurrentAnchor(b,:), CurrentDistance(b,:), CurrentAngle(b,:));
               Anchor_x(1,1) =  Anchor_data(b,1) - Ris0(1,1);
               Anchor_y(1,1) =  Anchor_data(b,2) - Ris0(1,2);
               Anchor_quant_x(1,1) = quantize_cluster(Anchor_x(1,1),3,2,3);
               Anchor_quant_y(1,1) = quantize_cluster(Anchor_y(1,1),3,2,3);
               q_x(1,b) = sum((Anchor_quant_x-Anchor_x).^2,[1,2]);
               q_y(1,b) = sum((Anchor_quant_y-Anchor_y).^2,[1,2]);
               quant_x(b,1) = mean( Anchor_quant_x,[1,2]);
               quant_y(b,1) = mean( Anchor_quant_y,[1,2]);
                q_x_data = q_x_data+(1/q_x(1,b));
                q_y_data = q_y_data+(1/q_y(1,b));
                LocationEstimation4(j,1) = LocationEstimation4(j,1)+((1/q_x(1,b))/q_x_data)*quant_x(b,1);
                LocationEstimation4(j,2) = LocationEstimation4(j,2)+((1/q_y(1,b))/q_y_data)*quant_y(b,1);
                LocationEstimation3(j,1) = LocationEstimation3(j,1)+weight(b,1)*quant_x(b,1);
                LocationEstimation3(j,2) = LocationEstimation3(j,2)+weight(b,2)*quant_y(b,1);
           end
           end
           if k >1
              for b = 1:j
                   if b<=5
                   [Distance_quant,Angle_quant] = GetMeasurementForEachAnchor(CurrentAnchor(b,:), Target, w_sigmaDistance, w_sigmaAngle, N);
                        Distance_t(k-1,:) = Distance_quant';
                        Angle_t(k-1,:) = Angle_quant';
                          CurrentDistance_t = Distance_t(k-1,:);
                          CurrentAngle_t = Angle_t(k-1,:);
                          Anchor_data(b,:) = ProposedLocAlgorithm(CurrentAnchor(b,:), CurrentDistance_t, CurrentAngle_t);
                          Anchor_x(1,1) =  Anchor_data(b,1) -  LocationEstimation4(j,1);
                          Anchor_y(1,1) =  Anchor_data(b,2) -  LocationEstimation4(j,2);
                          Anchor_quant_x(1,1) = quantize_cluster(Anchor_x(1,1),3,2,3);
                          Anchor_quant_y(1,1) = quantize_cluster(Anchor_y(1,1),3,2,3);
                          q_x(1,b) = sum((Anchor_quant_x-Anchor_x).^2,[1,2]);
                          q_y(1,b) = sum((Anchor_quant_y-Anchor_y).^2,[1,2]);
                          quant_x(b,1) = mean( Anchor_quant_x,[1,2]);
                          quant_y(b,1) = mean( Anchor_quant_y,[1,2]);
                          q_x_data = q_x_data+(1/q_x(1,b));
                          q_y_data = q_y_data+(1/q_y(1,b));
                          LocationEstimation4(j,1) = LocationEstimation4(j,1)+((1/q_x(1,b))/q_x_data)*quant_x(b,1);
                          LocationEstimation4(j,2) = LocationEstimation4(j,2)+((1/q_y(1,b))/q_y_data)*quant_y(b,1);
                          LocationEstimation3(j,1) = LocationEstimation3(j,1)+weight(b,1)*quant_x(b,1);
                          LocationEstimation3(j,2) = LocationEstimation3(j,2)+weight(b,2)*quant_y(b,1);
                   end
                   if b>5
                        [Distance_quant,Angle_quant] = GetMeasurementForEachAnchor(CurrentAnchor(b,:), Target, sigmaDistance, sigmaAngle, N);
                        Distance_t(k-1,:) = Distance_quant';
                        Angle_t(k-1,:) = Angle_quant';
                          CurrentDistance_t = Distance_t(k-1,:);
                          CurrentAngle_t = Angle_t(k-1,:);
                          Anchor_data(b,:) = ProposedLocAlgorithm(CurrentAnchor(b,:), CurrentDistance_t, CurrentAngle_t);
                          Anchor_x(1,1) =  Anchor_data(b,1) -  LocationEstimation4(j,1);
                          Anchor_y(1,1) =  Anchor_data(b,2) -  LocationEstimation4(j,2);
                          Anchor_quant_x(1,1) = quantize_cluster(Anchor_x(1,1),3,2,3);
                          Anchor_quant_y(1,1) = quantize_cluster(Anchor_y(1,1),3,2,3);
                          q_x(1,b) = sum((Anchor_quant_x-Anchor_x).^2,[1,2]);
                          q_y(1,b) = sum((Anchor_quant_y-Anchor_y).^2,[1,2]);
                          quant_x(b,1) = mean( Anchor_quant_x,[1,2]);
                          quant_y(b,1) = mean( Anchor_quant_y,[1,2]);
                          q_x_data = q_x_data+(1/q_x(1,b));
                          q_y_data = q_y_data+(1/q_y(1,b));
                          LocationEstimation4(j,1) = LocationEstimation4(j,1)+((1/q_x(1,b))/q_x_data)*quant_x(b,1);
                          LocationEstimation4(j,2) = LocationEstimation4(j,2)+((1/q_y(1,b))/q_y_data)*quant_y(b,1);
                            LocationEstimation3(j,1) = LocationEstimation3(j,1)+weight(b,1)*quant_x(b,1);
                             LocationEstimation3(j,2) = LocationEstimation3(j,2)+weight(b,2)*quant_y(b,1);
                   end
                   
                
                   
               end
           end
          % [Distance_quant,Angle_quant] = GetMeasurementForEachAnchor(CurrentAnchor(j,:), Target, sigmaDistance, sigmaAngle, N);
        %Distance_t(k-1,:) = Distance_quant';
        %Angle_t(k-1,:) = Angle_quant';
         %CurrentDistance_t = Distance_t(k-1,:);
        %CurrentAngle_t = Angle_t(k-1,:);
        %Anchor_data(1,:) = ProposedLocAlgorithm(CurrentAnchor(j,:), CurrentDistance_t, CurrentAngle_t);
       end
        ErrorProposedAlg4(j,1) = sqrt((Target(1,1) - LocationEstimation4(j,1))^2 + (Target(1,2) - LocationEstimation4(j,2))^2);
        ErrorProposedAlg3(j,1) = sqrt((Target(1,1) - LocationEstimation3(j,1))^2 + (Target(1,2) - LocationEstimation3(j,2))^2);
         %for k = 1:N
        % Anchor_data(k,:) = ProposedLocAlgorithm(CurrentAnchor(j,:), CurrentDistance(j,k), CurrentAngle(j,k));
        % Anchor_x(1,k) =  Anchor_data(k,1) - Ris0(1,1);
        % Anchor_y(1,k) =  Anchor_data(k,2) - Ris0(1,2);
         %Anchor_quant_x(1,k) = quantize_cluster(Anchor_x(1,k),3,2,1);
         %Anchor_quant_y(1,k) = quantize_cluster(Anchor_y(1,k),3,2,1);
       % end
      
        % calcluate the proposed algorithm
        %[TargetTemp] = ProposedLocAlgorithm(CurrentAnchor, CurrentDistance, CurrentAngle);
        %LocationEstimation(j,:) = TargetTemp;
         %ErrorProposedAlg(j,1) = sqrt((Target(1,1) - TargetTemp(1,1))^2 + (Target(1,2) - TargetTemp(1,2))^2);
        if j>=2
        [TargetTemp2] = RISPPADL(CurrentAnchor, CurrentDistance, CurrentAngle,Rdistance,Rangle,Ris);
        LocationEstimation2(j,:) = TargetTemp2;
        ErrorProposedAlg2(j,1) = sqrt((Target(1,1) - TargetTemp2(1,1))^2 + (Target(1,2) - TargetTemp2(1,2))^2);
        % calculate the error
        %[TargetTemp3] = PPProposedLocAlgorithm(CurrentAnchor, CurrentDistance, CurrentAngle);
        %LocationEstimation3(j,:) = TargetTemp3;
        %ErrorProposedAlg3(j,1) = sqrt((Target(1,1) - TargetTemp3(1,1))^2 + (Target(1,2) - TargetTemp3(1,2))^2);
        end

        
        % calculate the existing algorithm
        %if j >= 3
            %[TargetTemp1] = ExistingLocAlgorithm(CurrentAnchor,CurrentDistance);
            %LocationEstimation1(j,:) = TargetTemp1;
            %ErrorProposedAlg1(j,1) = sqrt((Target(1,1) - TargetTemp1(1,1))^2 + (Target(1,2) - TargetTemp1(1,2))^2);
        %end
    end    
   % next how to record the results for 1000 runs; we can only record the
   % errors 
   Error2(:,i) = ErrorProposedAlg2(4:end,1);
   Error3(:,i) = ErrorProposedAlg3;
   Error4(:,i) = ErrorProposedAlg4;
end    
%% plot the error with the number of anchor nodes
%AnchorNum = 1:m;
%AnchorNum1 = 3:m;
AnchorNum2 = 4:m;
AnchorNum3 = 1:m;
AnchorNum4 = 1:m;

Error2 = Error2';
Err2 = mean(Error2);
Error3 = Error3';
Err3 = mean(Error3);
Error4 = Error4';
Err4 = mean(Error4);
figure(1);
plot(AnchorNum2,Err2,'m-x','MarkerSize',8,'LineWidth',1.5)
hold on
plot(AnchorNum3,Err3,'b-*','MarkerSize',8,'LineWidth',1.5)
hold on
plot(AnchorNum4,Err4,'g-*','MarkerSize',8,'LineWidth',1.5)
xlim([1,20]);
%set(gca,'xtick',3:2:20);
legend('\fontsize{14} RPPL','\fontsize{14} suiji','\fontsize{14} quantize')
xlabel({'Number of Anchors'},'FontSize',14);
ylabel({'Location Error (meters)'},'FontSize',14);
hold off