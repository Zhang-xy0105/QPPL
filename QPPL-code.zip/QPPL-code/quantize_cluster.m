function [quant_data] = quantize_cluster(data, bits, q_cal,ebit)
  [m,~] = size(data);
  q_data = zeros(1,m);
  quant_data = zeros(1,m);
  original_data = zeros(1,m);
  original_data_zero = zeros(1,m);
  max_exponent = zeros(1,m);
  for i = 1:m
      original_data(1,i) = data(1,i);
      max_exponent(1,i) = data(1,i);
  end
  if data == original_data_zero
      for j = 1:m
         data(1,j) = 1;
      end
  end
  max_exponent = abs(data);
  max_exponent = log2(max_exponent);
  max_exponent = floor(max_exponent);
  for k = 1:m
      if max_exponent(1,k)<(-(2^(ebit-1)))
          max_exponent(1,k) = (-(2^(ebit-1)));
      end
      if max_exponent(1,k)>2^(ebit-1)-1
          max_exponent(1,k) = 2^(ebit-1)-1;
      end
      n = data(1,k)*(2^(-(max_exponent(1,k))+bits-2));
      cur_exp = 2^(max_exponent(1,k)-(bits-2));
      if q_cal == 1%%expectation
          p4left = 1-mod(n,1);
          p4right = mod(n,1);
          q_n_left = floor(n);
          if q_n_left<(-(2 ^(bits - 1)))
              q_n_left = (-(2 ^(bits - 1)));
          end
          if q_n_left>(2^(bits-1)-1)
              q_n_left = (2^(bits-1)-1);
          end
          q_n_left = q_n_left*cur_exp;
          q_n_right = ceil(n);
          if q_n_right<(-(2 ^(bits - 1)))
              q_n_right = (-(2 ^(bits - 1)));
          end
          if q_n_right > 2^(bits - 1)-1
             q_n_right = 2^(bits - 1)-1 ;
          end
          q_n_right = q_n_right*cur_exp;
          q_data(1,k) =  (q_n_left - data(1,k))^2 * p4left;
          q_data(1,k) = q_data(1,k) + (q_n_right-data(1,k))^2*p4right;
          q_data(1,k) = q_data(1,k)/(data(1,k)^2);
          if data(1,k) == original_data_zero(1,k)
              q_data(1,k) = original_data_zero(1,k);
          end
      end
      n = n + rand(1,1);
      n = floor(n);
      if n < (-(2^(bits-1)))
          n = (-(2^(bits-1)));
      end
      if n >(2^(bits-1)-1)
          n = (2^(bits-1)-1);
      end
      quant_data(1,k) = n*2^(max_exponent(1,k)-(bits-2));
  end
  if q_cal == 1%%expectation
      q = max(q_data);
  end
  if q_cal == 2%%SQE
      q = sum((original_data-quant_data)^2);
  end
end
  
      
          
          
          
  
  
  
  
  