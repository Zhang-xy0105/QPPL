function arr = RandSumZero(n)
    upper=1;
    lower=-1;
    arr=zeros(1,n);%n个0
    if n > 1                                                                   
        arr(1,1)=rand(1,1)*(upper-lower)+lower;
        asum=arr(1,1);
        for i=2:n-1
            if asum>0
                upper=1-asum;
                lower=-1;
            else
                lower=-1-asum;
                upper=1;
            end
            arr(1,i)=rand(1,1)*(upper-lower)+lower;
            asum=asum+arr(1,i);
        end
        arr(1,n)=-asum;
    end
end

