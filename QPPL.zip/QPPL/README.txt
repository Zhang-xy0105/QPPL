Test_Iterations----Figure3a
Test_SQE---figure3b
Test_Measurement-----figure4b
Test_AnchorNumber----figure4a
Test_Diffbits-----figure5
Test_Time-----figure6b
Test_Time-------figure6a
Test_Biggerarea-------figure8a
Test_Misbehaving----------figure7
Test_Tri--------------figure9b
Point_tri---------figure9a
Test_Dynamic---------figure10
Test_Gdop  AnchorGdop--------figure8b



GetMeasurementForEachAnchor
ProposedLocAlgorithm
quantize_clipping get_clip_gap
PPProposedLocAlgorithm
GPPADL
SingleAnchorLocModel