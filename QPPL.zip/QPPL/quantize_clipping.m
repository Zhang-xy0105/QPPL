function [wi, q] = quantize_clipping(data, bits, q_cal)
    % 使用二分法找到最优裁剪水平
    left = min(data(:));
    right = max(data(:));

    while right - left >= 1e-5
        mid_half = (right + left) / 2;
        mid_trip = (right + mid_half) / 2;
        [~, sse_half] = get_clip_gap(data, mid_half, bits, q_cal);
        [~, sse_trip] = get_clip_gap(data, mid_trip, bits, q_cal);
        if sse_half < sse_trip
            right = mid_trip;
        else
            left = mid_half;
        end
    end

   [wi, q] = get_clip_gap(data, left, bits, q_cal);
end