function [Gdop] = AnchorGdop(Anchor, Target)
[m,~] = size(Anchor);
[m1,n1] = size(Target);
%if m1 ~= 1
    %error('Error! Something is wrong on the distance ranging with the number of anchor ndoes!');
%end

%if n1 ~= 2
    %error('Error! Something is wrong on the angle ranging with the number of anchor node!');
%end 
A = zeros(2*m,2);
W = zeros(2*m,2*m);
S = zeros(1,m);
%AA = ones(2,2*m);
errord = 0.05;
errora = 0.0107;
k = errord/errora;
for i = 1:m
    W(i,i) = k*k;
end
for ii = m+1:2*m
    W(ii,ii) = 1;
end
for j = 1:m
    x = Target(1,1)-Anchor(j,1);
    y = Target(1,2)-Anchor(j,2);
    S(1,j) = sqrt(x*x+y*y);
    s = S(1,j)*S(1,j);
    A(j,1) = (-(y/s));
    A(j,2) = x/s;
    A(m+j,1) = x/S(1,j);
    A(m+j,2) = y/S(1,j); 
end

Gdop = sqrt(trace(inv(A'*W*A)));


    

