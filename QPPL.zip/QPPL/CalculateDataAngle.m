% �������ݼ���ʵ�ʽǶ� ʵ�ʾ���

clear global; clear variables;
%% setup
load RealDATA; 
RealDistance = zeros(50,1);
RealAngle = zeros(50,1);
x = 50;
y = 50;
RealAngle = zeros(50,1);
for i =1:50
    % get the distance measurement
    RealDistance(i) = sqrt((RealDATA(i,1)-x)^2 + (RealDATA(i,2)-y)^2);
    
    % get the angle measurement
    if x >= RealDATA(i,1) && y >= RealDATA(i,2)
        RealAngle(i) = atan((y - RealDATA(i,2))/(x - RealDATA(i,1)));
    elseif x < RealDATA(i,1) && y > RealDATA(i,2)
        RealAngle(i) = atan((y - RealDATA(i,2))/(x - RealDATA(i,1))) + pi;
    elseif x < RealDATA(i,1) && y < RealDATA(i,2)
        RealAngle(i) = atan((y - RealDATA(i,2))/(x - RealDATA(i,1))) + pi;
    elseif x > RealDATA(i,1) && y < RealDATA(i,2)
        RealAngle(i) = atan((y - RealDATA(i,2))/(x - RealDATA(i,1))) + 2*pi;
    end   
end

