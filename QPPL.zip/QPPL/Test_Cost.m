clear global; clear variables;
%load anchor; 
%Anchor = anchor;
%m = length(Anchor);
%load RealDATA;
Target = [50, 50];
m = 30;
N = 1000;
NN = 1000;
RT1 = zeros(5,N);
RT2 = zeros(5,N);
Anchor = rand(m,2)*100;
Distance = zeros(1,NN);
Angle = zeros(1,NN);

sigmaDistance = 3;
sigmaAngle = 0.01;

sigmaDistance1 = 5;
sigmaAngle1 = 0.03;
%LocationEstimation = zeros(N,2);
ErrorProposedAlg = zeros(10,1);
%LocationEstimation1 = zeros(N,2);
ErrorProposedAlg1 = zeros(10,1);
%LocationEstimation2 = zeros(N,2);
ErrorProposedAlg2 = zeros(10,1);
LocationEstimation3 = zeros(N,2);
ErrorProposedAlg3 = zeros(N,1);
Anchor_data = zeros(N,2);
Anchor_data1 = zeros(N,2);
Anchor_data2 = zeros(N,2);
Anchor_data3 = zeros(N,2);
Anchor_quant_x = zeros(1,m);
Anchor_quant_y = zeros(1,m);
Anchor_quant_x1 = zeros(1,m);
Anchor_quant_y1 = zeros(1,m);
Anchor_quant_x2 = zeros(1,m);
Anchor_quant_y2 = zeros(1,m);
Anchor_quant_x3 = zeros(1,m);
Anchor_quant_y3 = zeros(1,m);
q_data_x = zeros(1,m);
q_data_y = zeros(1,m);
q_data_x1 = zeros(1,m);
q_data_y1 = zeros(1,m);
q_data_x2 = zeros(1,m);
q_data_y2 = zeros(1,m);
q_data_x3 = zeros(1,m);
q_data_y3 = zeros(1,m);
Anchor_x = zeros(m,10);
Anchor_y = zeros(m,10);
Anchor_x1 = zeros(m,10);
Anchor_y1 = zeros(m,10);
Anchor_x2 = zeros(m,10);
Anchor_y2 = zeros(m,10);
Anchor_x3 = zeros(m,10);
Anchor_y3 = zeros(m,10);
R = 20;
Anchorr1 = zeros(R,1);
Anchorr2 = zeros(R,1);
Anchorx = zeros(R,1);
Anchory = zeros(R,1);
%for q = 1:m
 %   Anchor(q,:)= RealDATA(q,:);
%end
meanerror=zeros(10,1);
meanerror1=zeros(10,1);
meanerror2=zeros(10,1);
meanerror3=zeros(10,1);
Error = zeros(10,N);
Error1 = zeros(10,N);
Error2 = zeros(10,N);
Error3 = zeros(10,N);
RunningTime1 = zeros(10,1);
RunningTime2 = zeros(10,1);
Anchor_bits1 = zeros(10,N);

for a = 1:N
    LocationEstimation = zeros(10,2);
    %LocationEstimation1 = zeros(N,2);
    %LocationEstimation2 = zeros(N,2);
for x = 1:10
    for l = 3*x
        %tic;
   for k = 1:10
   for i = 1*k
      % P = 0;
        q_x = 0;
        q_y = 0;
       % q_x1 = 0;
       % q_y1 = 0;
       % q_x2 = 0;
      %  q_y2 = 0;
        %q_x3 = 0;
        %q_y3 = 0;
        for q = 1:l
        for r = 1:R
        [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
        Distance(1,:) = Distance_r';
        Angle(1,:) = Angle_r';
          Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance(1,:), Angle(1,:));
        %    S=rand(1,50);
               %   for n=1:1
                  %    S(n,:)=S(n,:)/sum(S(n,:));
                 % end
         if i == 1 

          Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation(1,1);
          Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation(1,2);
        %  Anchor_x1(q,i) =  Anchor_data(q,1) - LocationEstimation1(1,1);
          %Anchor_y1(q,i) =  Anchor_data(q,2) - LocationEstimation1(1,2);
         % Anchor_x2(q,i) =  Anchor_data(q,1) - LocationEstimation2(1,1);
          %Anchor_y2(q,i) =  Anchor_data(q,2) - LocationEstimation2(1,2);
          %Anchor_x3(q,i) =  Anchor_data(q,1) - LocationEstimation3(1,1);
          %Anchor_y3(q,i) =  Anchor_data(q,2) - LocationEstimation3(1,2);
         end
         if i > 1
          Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation(i-1,1);
          Anchory(r,1)=  Anchor_data(q,2) - LocationEstimation(i-1,2);
         % Anchor_x1(q,i) =  Anchor_data(q,1) - LocationEstimation1(i-1,1);
          %Anchor_y1(q,i) =  Anchor_data(q,2) - LocationEstimation1(i-1,2);
          %Anchor_x2(q,i) =  Anchor_data(q,1) - LocationEstimation2(i-1,1);
          %Anchor_y2(q,i) =  Anchor_data(q,2) - LocationEstimation2(i-1,2);
          %Anchor_x3(q,i) =  Anchor_data(q,1) - LocationEstimation3(i-1,1);
          %Anchor_y3(q,i) =  Anchor_data(q,2) - LocationEstimation3(i-1,2);
         end
         %bit=4
        end
         if q<=0.2*l
                    [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,5,'SQE');
                    [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,5,'SQE');
                   % [Anchor_quant_x1(1,q),q_data_x1(1,q)] = quantize_clipping(Anchor_x1(q,i),5,'SQE');
                    %[Anchor_quant_y1(1,q),q_data_y1(1,q)] = quantize_clipping(Anchor_y1(q,i),5,'SQE');
                    %[Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),5,'SQE');
                    %[Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),5,'SQE');
               

         else
                    [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,3,'SQE');
                    [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,3,'SQE');
                   % [Anchor_quant_x1(1,q),q_data_x1(1,q)] = quantize_clipping(Anchor_x1(q,i),3,'SQE');
                   % [Anchor_quant_y1(1,q),q_data_y1(1,q)] = quantize_clipping(Anchor_y1(q,i),3,'SQE');
                   % [Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),3,'SQE');
                   % [Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),3,'SQE');

         end
             data_bits_temp=dec2bin(q_data_x(1,q));
             c =length(data_bits_temp);
        
                Anchor_bits1(x,a) = Anchor_bits1(x,a) +c;

          Anchor_quant_x(1,q) = mean(Anchorr1);
          Anchor_quant_y(1,q) = mean(Anchorr2);
          q_x = q_x + 1/q_data_x(1,q);
          q_y = q_y + 1/q_data_y(1,q);
          
        %  q_x1 = q_x1 + 1/q_data_x1(1,q);
         % q_y1 = q_y1 + 1/q_data_y1(1,q);
          
         % q_x2 = q_x2 + 1/q_data_x2(1,q);
        %  q_y2 = q_y2 + 1/q_data_y2(1,q);
          
        %  [Anchor_quant_x3(1,q),q_data_x3(1,q)] = quantize_clipping(Anchor_x3(q,i),3,'SQE');
         % [Anchor_quant_y3(1,q),q_data_y3(1,q)] = quantize_clipping(Anchor_y3(q,i),3,'SQE');
         % q_x3 = q_x3 + 1/q_data_x3(1,q);
         % q_y3 = q_y3 + 1/q_data_y3(1,q);
        end
        
        if i == 1
            for q = 1:l
                LocationEstimation(1,1) = LocationEstimation(1,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                LocationEstimation(1,2) = LocationEstimation(1,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
               % LocationEstimation1(1,1) = LocationEstimation1(1,1)+Anchor_quant_x1(1,q) * 1/m;
               % LocationEstimation1(1,2) = LocationEstimation1(1,2)+Anchor_quant_y1(1,q) * 1/m;
               % LocationEstimation2(1,1) = LocationEstimation2(1,1)+Anchor_quant_x2(1,q) * S(1,q);
               % LocationEstimation2(1,2) = LocationEstimation2(1,2)+Anchor_quant_y2(1,q) * S(1,q);
               % LocationEstimation3(1,1) = LocationEstimation3(1,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
              %  LocationEstimation3(1,2) = LocationEstimation3(1,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
            end  
        end
        if i > 1
            LocationEstimation(i,1) = LocationEstimation(i-1,1);
            LocationEstimation(i,2) = LocationEstimation(i-1,2);
          %  LocationEstimation1(i,1) = LocationEstimation1(i-1,1);
           % LocationEstimation1(i,2) = LocationEstimation1(i-1,2);
           % LocationEstimation2(i,1) = LocationEstimation2(i-1,1);
          %  LocationEstimation2(i,2) = LocationEstimation2(i-1,2);
         %   LocationEstimation3(i,1) = LocationEstimation3(i-1,1);
          %  LocationEstimation3(i,2) = LocationEstimation3(i-1,2);
             for q = 1:l
                LocationEstimation(i,1) = LocationEstimation(i,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                LocationEstimation(i,2) = LocationEstimation(i,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
               % LocationEstimation1(i,1) = LocationEstimation1(i,1)+Anchor_quant_x1(1,q) * 1/m;
               % LocationEstimation1(i,2) = LocationEstimation1(i,2)+Anchor_quant_y1(1,q) * 1/m;

                
                %LocationEstimation2(i,1) = LocationEstimation2(i,1)+Anchor_quant_x2(1,q) * S(1,q);
               % LocationEstimation2(i,2) = LocationEstimation2(i,2)+Anchor_quant_y2(1,q) * S(1,q);
               % LocationEstimation3(i,1) = LocationEstimation3(i,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
               % LocationEstimation3(i,2) = LocationEstimation3(i,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
            end  
        end
        ErrorProposedAlg(i,:) = sqrt((Target(1,1) - LocationEstimation(i,1))^2 + (Target(1,2) - LocationEstimation(i,2))^2);
       % ErrorProposedAlg1(i,:) = sqrt((Target(1,1) - LocationEstimation1(i,1))^2 + (Target(1,2) - LocationEstimation1(i,2))^2);
        %ErrorProposedAlg2(i,:) = sqrt((Target(1,1) - LocationEstimation2(i,1))^2 + (Target(1,2) - LocationEstimation2(i,2))^2);
       % ErrorProposedAlg3(i,:) = sqrt((Target(1,1) - LocationEstimation3(i,1))^2 + (Target(1,2) - LocationEstimation3(i,2))^2);
   end

      meanerror(k,:)=ErrorProposedAlg(i,:);
      %meanerror1(k,:)=ErrorProposedAlg1(i,:);
     % meanerror2(k,:)=ErrorProposedAlg2(i,:);
     % meanerror3(k,:)=ErrorProposedAlg3(i,:);
    end
       % RT_QUA=toc;
    end
    %RunningTime1(x,1) = RT_QUA;
   %  Error1(:,a) = meanerror1(:,1);
    % Error2(:,a) = meanerror2(:,1);
    % Error3(:,a) = meanerror3(:,1);
end
           
 %RT1(:,a) = RunningTime1(:,1);
end

N = 1000;
Anchor_bits2 = zeros(10,N);
location = zeros(10,2);
for a = 1:N
   % LocationEstimation = zeros(N,2);
   % LocationEstimation1 = zeros(10,2);
    %LocationEstimation2 = zeros(20,2);
for e = 1:10
    LocationEstimation1 = zeros(10,2);
    for h = 3*e
   %  tic;
for k = 1:10
   for i = 1*k
      % P = 0;
        %q_x = 0;
        %q_y = 0;
        q_x1 = 0;
        q_y1 = 0;
        q_x2 = 0;
        q_y2 = 0;
        %q_x3 = 0;
        %q_y3 = 0;
        for q = 1:h
        [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance1, sigmaAngle1, NN);
        Distance(1,:) = Distance_r';
        Angle(1,:) = Angle_r';
          Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance(1,:), Angle(1,:));
         %   S=rand(1,50);
                %  for n=1:1
                    %  S(n,:)=S(n,:)/sum(S(n,:));
                 % end
         if i == 1 

          %Anchor_x(q,i) =  Anchor_data(q,1) - LocationEstimation(1,1);
          %Anchor_y(q,i) =  Anchor_data(q,2) - LocationEstimation(1,2);
          Anchor_x1(q,i) =  Anchor_data(q,1) - LocationEstimation1(1,1);
          Anchor_y1(q,i) =  Anchor_data(q,2) - LocationEstimation1(1,2);
         % Anchor_x2(q,i) =  Anchor_data(q,1) - LocationEstimation2(1,1);
          %Anchor_y2(q,i) =  Anchor_data(q,2) - LocationEstimation2(1,2);
          %Anchor_x3(q,i) =  Anchor_data(q,1) - LocationEstimation3(1,1);
          %Anchor_y3(q,i) =  Anchor_data(q,2) - LocationEstimation3(1,2);
         end
         if i > 1
          %Anchor_x(q,i) =  Anchor_data(q,1) - LocationEstimation(i-1,1);
          %Anchor_y (q,i)=  Anchor_data(q,2) - LocationEstimation(i-1,2);
          Anchor_x1(q,i) =  Anchor_data(q,1)-LocationEstimation1(i-1,1);
          Anchor_y1(q,i) =  Anchor_data(q,2)-LocationEstimation1(i-1,2);
         % Anchor_x2(q,i) =  Anchor_data(q,1) - LocationEstimation2(i-1,1);
         % Anchor_y2(q,i) =  Anchor_data(q,2) - LocationEstimation2(i-1,2);
          %Anchor_x3(q,i) =  Anchor_data(q,1) - LocationEstimation3(i-1,1);
          %Anchor_y3(q,i) =  Anchor_data(q,2) - LocationEstimation3(i-1,2);
         end
         %bit=4
         %if q<=0.2*m
                    %[Anchor_quant_x(1,q),q_data_x(1,q)] = quantize_clipping(Anchor_x(q,i),5,'SQE');
                    %[Anchor_quant_y(1,q),q_data_y(1,q)] = quantize_clipping(Anchor_y(q,i),5,'SQE');
                  %  [Anchor_quant_x1(1,q),q_data_x1(1,q)] = quantize_clipping(Anchor_x1(q,i),5,'SQE');
                  %  [Anchor_quant_y1(1,q),q_data_y1(1,q)] = quantize_clipping(Anchor_y1(q,i),5,'SQE');
                   % [Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),5,'SQE');
                  %  [Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),5,'SQE');
                    
                    
       %  else
                   % [Anchor_quant_x(1,q),q_data_x(1,q)] = quantize_clipping(Anchor_x(q,i),3,'SQE');
                  %  [Anchor_quant_y(1,q),q_data_y(1,q)] = quantize_clipping(Anchor_y(q,i),3,'SQE');
                   % [Anchor_quant_x1(1,q),q_data_x1(1,q)] = quantize_clipping(Anchor_x1(q,i),3,'SQE');
                   % [Anchor_quant_y1(1,q),q_data_y1(1,q)] = quantize_clipping(Anchor_y1(q,i),3,'SQE');
                   % [Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),3,'SQE');
                   % [Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),3,'SQE');
         %end
         % q_x = q_x + 1/q_data_x(1,q);
         % q_y = q_y + 1/q_data_y(1,q);
          
        %  q_x1 = q_x1 + 1/q_data_x1(1,q);
         % q_y1 = q_y1 + 1/q_data_y1(1,q);
          
        %  q_x2 = q_x2 + 1/q_data_x2(1,q);
         % q_y2 = q_y2 + 1/q_data_y2(1,q);
          
        %  [Anchor_quant_x3(1,q),q_data_x3(1,q)] = quantize_clipping(Anchor_x3(q,i),3,'SQE');
         % [Anchor_quant_y3(1,q),q_data_y3(1,q)] = quantize_clipping(Anchor_y3(q,i),3,'SQE');
         % q_x3 = q_x3 + 1/q_data_x3(1,q);
         % q_y3 = q_y3 + 1/q_data_y3(1,q);

             data_bits_temp=dec2bin(Anchor_x1(q,i));
             Anchor_bits2(e,a) =  Anchor_bits2(e,a) + 2*length(data_bits_temp);
        end
        
        if i == 1
            for q = 1:h
               % LocationEstimation(1,1) = LocationEstimation(1,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
               % LocationEstimation(1,2) = LocationEstimation(1,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                LocationEstimation1(1,1) = LocationEstimation1(1,1)+Anchor_x1(q,i) * 1/h;
                LocationEstimation1(1,2) = LocationEstimation1(1,2)+Anchor_y1(q,i) * 1/h;
               % LocationEstimation2(1,1) = LocationEstimation2(1,1)+Anchor_quant_x2(1,q) * S(1,q);
               % LocationEstimation2(1,2) = LocationEstimation2(1,2)+Anchor_quant_y2(1,q) * S(1,q);
               % LocationEstimation3(1,1) = LocationEstimation3(1,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
              %  LocationEstimation3(1,2) = LocationEstimation3(1,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
            end  
        end
        if i > 1
            %LocationEstimation(i,1) = LocationEstimation(i-1,1);
           % LocationEstimation(i,2) = LocationEstimation(i-1,2);
            LocationEstimation1(i,1) = LocationEstimation1(i-1,1);
            LocationEstimation1(i,2) = LocationEstimation1(i-1,2);
          %  LocationEstimation2(i,1) = LocationEstimation2(i-1,1);
           % LocationEstimation2(i,2) = LocationEstimation2(i-1,2);
         %   LocationEstimation3(i,1) = LocationEstimation3(i-1,1);
         %   LocationEstimation3(i,2) = LocationEstimation3(i-1,2);
             for q = 1:h
                %LocationEstimation(i,1) = LocationEstimation(i,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
               % LocationEstimation(i,2) = LocationEstimation(i,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                LocationEstimation1(i,1) = LocationEstimation1(i,1)+Anchor_x1(q,i) * 1/h;
                LocationEstimation1(i,2) = LocationEstimation1(i,2)+Anchor_x1(q,i) * 1/h;
          
                
                %LocationEstimation2(i,1) = LocationEstimation2(i,1)+Anchor_quant_x2(1,q) * S(1,q);
               % LocationEstimation2(i,2) = LocationEstimation2(i,2)+Anchor_quant_y2(1,q) * S(1,q);
               % LocationEstimation3(i,1) = LocationEstimation3(i,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
               % LocationEstimation3(i,2) = LocationEstimation3(i,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
            end  
        end
        %ErrorProposedAlg(i,:) = sqrt((Target(1,1) - LocationEstimation(i,1))^2 + (Target(1,2) - LocationEstimation(i,2))^2);
        ErrorProposedAlg1(i,:) = sqrt((Target(1,1) - LocationEstimation1(i,1))^2 + (Target(1,2) - LocationEstimation1(i,2))^2);
        %ErrorProposedAlg2(i,:) = sqrt((Target(1,1) - LocationEstimation2(i,1))^2 + (Target(1,2) - LocationEstimation2(i,2))^2);
       % ErrorProposedAlg3(i,:) = sqrt((Target(1,1) - LocationEstimation3(i,1))^2 + (Target(1,2) - LocationEstimation3(i,2))^2);
   end

     % meanerror(k,:)=ErrorProposedAlg(i,:);
      meanerror1(k,:)=ErrorProposedAlg1(i,:);
     % meanerror2(k,:)=ErrorProposedAlg2(i,:);
     % meanerror3(k,:)=ErrorProposedAlg3(i,:);
end
 %  RT_NONE=toc;
    end
    % RunningTime2(e,1) = RT_NONE;
     location(e,1)=LocationEstimation1(10,1);
     location(e,2)=LocationEstimation1(10,2);
end
     %RT2(:,a) = RunningTime2(:,1);
     %Error(:,a) = meanerror(:,1);
 
     %Error2(:,a) = meanerror2(:,1);
    % Error3(:,a) = meanerror3(:,1);
end

Anchor_bits1 = Anchor_bits1';
bits1 = mean(Anchor_bits1);
 
Anchor_bits2 = Anchor_bits2';
bits2 = mean(Anchor_bits2);
figure(1);
hold on
plot((3:3:30),bits1,'r-o','MarkerSize',8,'LineWidth',1.5)
plot((3:3:30),bits2,'m->','MarkerSize',8,'LineWidth',1.5)
xlim([3, 30]);%只设定x轴的绘制范围
ylim([1e1, 1e4]);
set(gca,'XTick',(3:3:30));
 set(gca,'YScale','log');
%plot((1:1:10),Err2,'m-x','MarkerSize',8,'LineWidth',1.5)
%plot((1:1:10),Err3,'b-*','MarkerSize',8,'LineWidth',1.5)
hold off

legend('\fontsize{15} QPPL','\fontsize{15} LSAL');
xlabel({'Number of Anchors '},'FontSize',14);
ylabel({'Communication Overhead(bits)'},'FontSize',14);
