function points = generateNonUniformRandomPointsInTriangle(n, vertex1, vertex2, vertex3)
    % n 是要生成的点的数量
    % vertex1, vertex2, vertex3 是三角形的三个顶点的坐标，格式为 [x, y]
    
    points = zeros(n, 2); % 初始化点的数组
    
    for i = 1:n
        % 使用贝塔分布生成随机参数 t 和 u
        alpha = 7; % 贝塔分布的形状参数
        beta = 7;
        t = betarnd(alpha, beta);
        u = betarnd(alpha, beta);
        
        % 确保 t + u <= 1
        while t + u > 1
            t = betarnd(alpha, beta);
            u = betarnd(alpha, beta);
        end
        
        % 计算点的坐标
        x = (1 - t - u) * vertex1(1) + t * vertex2(1) + u * vertex3(1);
        y = (1 - t - u) * vertex1(2) + t * vertex2(2) + u * vertex3(2);
        
        % 存储点的坐标
        points(i, :) = [x, y];
    end
end