clear global; clear variables;
m = 30;
Target = [50, 50];
sigmaDistance = 3;
sigmaAngle = 0.01;
sigmaDistance0 =5;
sigmaAngle0 = 0.03;

N = 1000; % the number of the measurements
NN = 1000; % the number of runs to reduce the randomness
Error1 = zeros(m/3,NN);
Error2 = zeros(m/3,NN);
Error3 = zeros(m/3,NN);
%Error4 = zeros(m/3,NN);
%Error5 = zeros(m/3,NN);
R = 30;
%Anchorr1 = zeros(R,1);
%Anchorr2 = zeros(R,1);
Anchorx = zeros(R,1);
Anchory = zeros(R,1);
Anchorx3 = zeros(R,1);
Anchory3 = zeros(R,1);
Anchorx2 = zeros(R,1);
Anchory2 = zeros(R,1);
%LocationEstimation4 = zeros(m/3,2);
%ErrorProposedAlg4 = zeros(m/3,1); 


    Anchor = rand(m,2)*100;
    Anchor2 = rand(m,2)*1000;
    Anchor3 = rand(m,2)*10000;
    Distance = zeros(m,NN);
    Angle = zeros(m,NN);
    Distance_w = zeros(1,NN);
    Angle_w = zeros(1,NN);
    Distance1 = zeros(m,NN);
    Angle1 = zeros(m,NN);
    Distance_w1 = zeros(1,NN);
    Angle_w1 = zeros(1,NN);
    Distance2 = zeros(m,NN);
    Angle2 = zeros(m,NN);
    Distance_w2 = zeros(1,NN);
    Angle_w2 = zeros(1,NN);
for i = 1:NN
          Anchor1 = randi([1,30],1,3);

           ErrorProposedAlg3 = zeros(m/3,1);
           ErrorProposedAlg1 = zeros(m/3,1);
           %LocationEstimation2 = zeros(m/3,2);
           ErrorProposedAlg2 = zeros(m/3,1); 
    
           %LocationEstimation3 = zeros(m/3,2);
           %ErrorProposedAlg3 = zeros(m/3,1); 
    for n = 1:m
        Anchor0 = Anchor(n,:);
        if ismember(n,Anchor1) == 0
            [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, NN);
        else
           [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance0, sigmaAngle0, NN);
        end
       Distance(n,:) = Distance0';
       Angle(n,:) = Angle0';
    end
      for j = 1:(m/3)
          Anchor_data = zeros(j*3,2);
          Anchor_quant_x = zeros(1,j*3);
          Anchor_quant_y = zeros(1,j*3);
          
          Anchorx1 = zeros(1,j*3);
          Anchory1 = zeros(1,j*3);
          q_data_x = zeros(1,j*3); 
          q_data_y = zeros(1,j*3);
          Anchor_x = zeros(j*3,20);
          Anchor_y = zeros(j*3,20);
          LocationEstimation1 = zeros(10,2);
          %LocationEstimation5 = zeros(10,2);
          CurrentAnchor = Anchor(1:j*3,:);
          CurrentDistance = Distance(1:j*3,:);
          CurrentAngle = Angle(1:j*3,:);
          for t = 1:10
               q_x = 0;
               q_y = 0;
                for q = 1:j*3
                 for r = 1:R
                  if ismember(q,Anchor1) == 0
                           [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
                  else                                                                                 
                            [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance0, sigmaAngle0, NN);
                  end
                      Distance_w(1,:) = distance_w';
                      Angle_w(1,:) = angle_w';
                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance_w(1,:), Angle_w(1,:));
                   if t == 1 
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(1,2);
                   end
                 
                   if t > 1
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(t-1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(t-1,2);
                   end
                 end
                  % Anchor_x(q,t) = mean(Anchorx);
                  % Anchor_y(q,t) = mean(Anchory);
                   if q<=0.2*j*3
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,5,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,5,'SQE');
                   else
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,3,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,3,'SQE');
                   end
                  % Anchorr1 = Anchorr1';
                  % Anchorr2 = Anchorr2';
                   Anchor_quant_x(1,q) = mean(Anchorr1);
                   Anchor_quant_y(1,q) = mean(Anchorr2);
                    q_x = q_x + 1/q_data_x(1,q);
                    q_y = q_y + 1/q_data_y(1,q);
                   % Anchorx = Anchorx';
                    %Anchory = Anchory';

                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance_w(1,:), Angle_w(1,:));
               
                end
                if t == 1
                   for q = 1:j*3
                      LocationEstimation1(1,1) = LocationEstimation1(1,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                      LocationEstimation1(1,2) = LocationEstimation1(1,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);

                   end
                end
                if t > 1
                     LocationEstimation1(t,1) = LocationEstimation1(t-1,1);
                     LocationEstimation1(t,2) = LocationEstimation1(t-1,2);

                    for q = 1:j*3
                         LocationEstimation1(t,1) = LocationEstimation1(t,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                         LocationEstimation1(t,2) = LocationEstimation1(t,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                   %   LocationEstimation5(t,1) = LocationEstimation5(t,1)+ Anchorx1(1,q) * 1/(j*3);
                   %   LocationEstimation5(t,2) = LocationEstimation5(t,2)+ Anchory1(1,q) * 1/(j*3);
                    end
                end
          end
           ErrorProposedAlg1(j,:) = sqrt((Target(1,1) - LocationEstimation1(t,1))^2 + (Target(1,2) - LocationEstimation1(t,2))^2);    
      end
 %1000*1000     
   for n = 1:m
        Anchor0 = Anchor2(n,:);
        if ismember(n,Anchor1) == 0
            [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, NN);
        else
           [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance0, sigmaAngle0, NN);
        end
       Distance1(n,:) = Distance0';
       Angle1(n,:) = Angle0';
    end
      for j = 1:(m/3)
          Anchor_data = zeros(j*3,2);
          Anchor_quant_x = zeros(1,j*3);
          Anchor_quant_y = zeros(1,j*3);
          
          Anchorx1 = zeros(1,j*3);
          Anchory1 = zeros(1,j*3);
          q_data_x = zeros(1,j*3); 
          q_data_y = zeros(1,j*3);
          Anchor_x = zeros(j*3,20);
          Anchor_y = zeros(j*3,20);
          LocationEstimation2 = zeros(10,2);
          %LocationEstimation5 = zeros(10,2);
          CurrentAnchor = Anchor2(1:j*3,:);
          CurrentDistance = Distance1(1:j*3,:);
          CurrentAngle = Angle1(1:j*3,:);
          for t = 1:10
               q_x = 0;
               q_y = 0;
                for q = 1:j*3
                 for r = 1:R
                  if ismember(q,Anchor1) == 0
                           [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor2(q,:), Target, sigmaDistance, sigmaAngle, NN);
                  else                                                                                 
                            [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor2(q,:), Target, sigmaDistance0, sigmaAngle0, NN);
                  end
                      Distance_w1(1,:) = distance_w';
                      Angle_w1(1,:) = angle_w';
                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor2(q,:), Distance_w1(1,:), Angle_w1(1,:));
                   if t == 1 
                      Anchorx2(r,1) =  Anchor_data(q,1) - LocationEstimation2(1,1);
                      Anchory2(r,1) =  Anchor_data(q,2) - LocationEstimation2(1,2);
                   end
                 
                   if t > 1
                      Anchorx2(r,1) =  Anchor_data(q,1) - LocationEstimation2(t-1,1);
                      Anchory2(r,1) =  Anchor_data(q,2) - LocationEstimation2(t-1,2);
                   end
                 end
                  % Anchor_x(q,t) = mean(Anchorx);
                  % Anchor_y(q,t) = mean(Anchory);
                   if q<=0.2*j*3
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx2,5,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory2,5,'SQE');
                   else
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx2,3,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory2,3,'SQE');
                   end
                  % Anchorr1 = Anchorr1';
                  % Anchorr2 = Anchorr2';
                   Anchor_quant_x(1,q) = mean(Anchorr1);
                   Anchor_quant_y(1,q) = mean(Anchorr2);
                    q_x = q_x + 1/q_data_x(1,q);
                    q_y = q_y + 1/q_data_y(1,q);
                   % Anchorx = Anchorx';
                    %Anchory = Anchory';

                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor2(q,:), Distance_w1(1,:), Angle_w1(1,:));
                    Anchorx1(1,q) = Anchor_data(q,1) - LocationEstimation2(1,1);
                    Anchory1(1,q) = Anchor_data(q,2) - LocationEstimation2(1,2);
                end
                if t == 1
                   for q = 1:j*3
                      LocationEstimation2(1,1) = LocationEstimation2(1,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                      LocationEstimation2(1,2) = LocationEstimation2(1,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                   
                   end
                end
                if t > 1
                     LocationEstimation2(t,1) = LocationEstimation2(t-1,1);
                     LocationEstimation2(t,2) = LocationEstimation2(t-1,2);
          
                    for q = 1:j*3
                         LocationEstimation2(t,1) = LocationEstimation2(t,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                         LocationEstimation2(t,2) = LocationEstimation2(t,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                   %   LocationEstimation5(t,1) = LocationEstimation5(t,1)+ Anchorx1(1,q) * 1/(j*3);
                   %   LocationEstimation5(t,2) = LocationEstimation5(t,2)+ Anchory1(1,q) * 1/(j*3);
                    end
                end
          end
           ErrorProposedAlg2(j,:) = sqrt((Target(1,1) - LocationEstimation2(t,1))^2 + (Target(1,2) - LocationEstimation2(t,2))^2);    
      end
      
       %10000*10000  
   for n = 1:m
        Anchor0 = Anchor3(n,:);
        if ismember(n,Anchor1) == 0
            [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, NN);
        else
           [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, NN);
        end
       Distance2(n,:) = Distance0';
       Angle2(n,:) = Angle0';
    end
      for j = 1:(m/3)
          Anchor_data = zeros(j*3,2);
          Anchor_quant_x = zeros(1,j*3);
          Anchor_quant_y = zeros(1,j*3);
          
          Anchorx1 = zeros(1,j*3);
          Anchory1 = zeros(1,j*3);
          q_data_x = zeros(1,j*3); 
          q_data_y = zeros(1,j*3);
          Anchor_x = zeros(j*3,20);
          Anchor_y = zeros(j*3,20);
          LocationEstimation3 = zeros(10,2);
          %LocationEstimation5 = zeros(10,2);
          CurrentAnchor = Anchor3(1:j*3,:);
          CurrentDistance = Distance2(1:j*3,:);
          CurrentAngle = Angle2(1:j*3,:);
          for t = 1:10
               q_x = 0;
               q_y = 0;
                for q = 1:j*3
                 for r = 1:R
                  if ismember(q,Anchor1) == 0
                           [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor3(q,:), Target, sigmaDistance, sigmaAngle, NN);
                  else                                                                                 
                            [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor3(q,:), Target, sigmaDistance0, sigmaAngle0, NN);
                  end
                      Distance_w2(1,:) = distance_w';
                      Angle_w2(1,:) = angle_w';
                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor3(q,:), Distance_w2(1,:), Angle_w2(1,:));
                   if t == 1 
                      Anchorx3(r,1) =  Anchor_data(q,1) - LocationEstimation3(1,1);
                      Anchory3(r,1) =  Anchor_data(q,2) - LocationEstimation3(1,2);
                   end
                 
                   if t > 1
                      Anchorx3(r,1) =  Anchor_data(q,1) - LocationEstimation3(t-1,1);
                      Anchory3(r,1) =  Anchor_data(q,2) - LocationEstimation3(t-1,2);
                   end
                 end
                  % Anchor_x(q,t) = mean(Anchorx);
                  % Anchor_y(q,t) = mean(Anchory);
                   if q<=0.2*j*3
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx3,3,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory3,3,'SQE');
                   else
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx3,8,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory3,8,'SQE');
                   end
                  % Anchorr1 = Anchorr1';
                  % Anchorr2 = Anchorr2';
                   Anchor_quant_x(1,q) = mean(Anchorr1);
                   Anchor_quant_y(1,q) = mean(Anchorr2);
                    q_x = q_x + 1/q_data_x(1,q);
                    q_y = q_y + 1/q_data_y(1,q);
                   % Anchorx = Anchorx';
                    %Anchory = Anchory';

                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor3(q,:), Distance_w2(1,:), Angle_w2(1,:));
                    Anchorx1(1,q) = Anchor_data(q,1) - LocationEstimation3(1,1);
                    Anchory1(1,q) = Anchor_data(q,2) - LocationEstimation3(1,2);
                end
                if t == 1
                   for q = 1:j*3
                      LocationEstimation3(1,1) = LocationEstimation3(1,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                      LocationEstimation3(1,2) = LocationEstimation3(1,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                   
                   end
                end
                if t > 1
                     LocationEstimation3(t,1) = LocationEstimation3(t-1,1);
                     LocationEstimation3(t,2) = LocationEstimation3(t-1,2);
          
                    for q = 1:j*3
                         LocationEstimation3(t,1) = LocationEstimation3(t,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                         LocationEstimation3(t,2) = LocationEstimation3(t,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                   %   LocationEstimation5(t,1) = LocationEstimation5(t,1)+ Anchorx1(1,q) * 1/(j*3);
                   %   LocationEstimation5(t,2) = LocationEstimation5(t,2)+ Anchory1(1,q) * 1/(j*3);
                    end
                end
          end
           ErrorProposedAlg3(j,:) = sqrt((Target(1,1) - LocationEstimation3(t,1))^2 + (Target(1,2) - LocationEstimation3(t,2))^2);    
      end
      
         Error1(:,i) = ErrorProposedAlg1(:,1);
         Error2(:,i) = ErrorProposedAlg2(:,1);
         Error3(:,i) = ErrorProposedAlg3(:,1);
        % Error4(:,i) = ErrorProposedAlg4(:,1);
       % Error5(:,i) = ErrorProposedAlg5(:,1);
 
end

AnchorNum1 = (3:3:m);
AnchorNum2 = (3:3:m);
AnchorNum3 = (3:3:m);
%AnchorNum4 = (2:2:m);

Error1 = Error1';
Err1 = mean(Error1);

Error2 = Error2';
Err2 = mean(Error2);

Error3 = Error3';
Err3 = mean(Error3);

%Err2(1,1)=NaN;
figure(1);
set(gca,'xtick',(3:3:30));
plot((3:3:30),Err1,'r-o','MarkerSize',8,'LineWidth',1.5)  
hold on
plot((3:3:30),Err2,'b-s','MarkerSize',8,'LineWidth',1.5)
hold on
%plot((3:3:30),Err4,'c-+','MarkerSize',8,'LineWidth',1.5)
%hold on
plot((3:3:30),Err3,'k->','MarkerSize',8,'LineWidth',1.5)
%plot((3:3:30),Err5,'m->','MarkerSize',8,'LineWidth',1.5)
set(gca,'xtick',(3:3:30));
xlim([3, 30]);
%set(gca,'xtick',3:2:20);
legend('\fontsize{15} s=100','\fontsize{15} s=1000','\fontsize{15} s=10000')
xlabel({'Number of Anchors'},'FontSize',14);
ylabel({'Location Error (meters)'},'FontSize',14);
hold off

