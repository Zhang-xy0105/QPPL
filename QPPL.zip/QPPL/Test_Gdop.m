clear global; clear variables;
m=30;
Target1 = [50,50];
Target2 = [500,500];
Target3 = [5000,5000];
NN = 1000;
AGdop1 = zeros(NN,10);
AGdop2 = zeros(NN,10);
AGdop3 = zeros(NN,10);
for j = 1:NN
Anchor1 = rand(m,2)*100;
Anchor2 = rand(m,2)*1000;
Anchor3 = rand(m,2)*10000;
  for i = 1:10
    CurrentAnchor1 = Anchor1(1:i*3,:);
    AGdop1(j,i) = AnchorGdop(CurrentAnchor1, Target1);
    CurrentAnchor2 = Anchor2(1:i*3,:);
    AGdop2(j,i) = AnchorGdop(CurrentAnchor2, Target2);
    CurrentAnchor3 = Anchor3(1:i*3,:);
    AGdop3(j,i) = AnchorGdop(CurrentAnchor3, Target3);
  end
end
AnchorNum = 3:3:30;
Gdop1 = mean(AGdop1);
Gdop2 = mean(AGdop2);
Gdop3 = mean(AGdop3);
figure(1);
plot((3:3:30),Gdop1,'r-o','MarkerSize',8,'LineWidth',1.5)
hold on
plot((3:3:30),Gdop2,'b-s','MarkerSize',8,'LineWidth',1.5)
hold on
plot((3:3:30),Gdop3,'k->','MarkerSize',8,'LineWidth',1.5)
set(gca,'xtick',(3:3:30));
xlim([3, 30]);
legend('\fontsize{14} s=100','\fontsize{14} s=1000','\fontsize{14} s=10000')
xlabel({'Number of Anchor nodes'},'FontSize',14);
ylabel({'GDOP'},'FontSize',14);
hold off