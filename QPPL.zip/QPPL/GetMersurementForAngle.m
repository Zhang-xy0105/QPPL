function [angle] = GetMersurementForAngle(Anchor,Target,sigmaAngle,N)
% ����Ƕ���Ϣ
x1 = Anchor(1,1); y1 = Anchor(1,2); % the location of the anchor node
x = Target(1,1); y = Target(1,2); % the location of the target node

sigmaA = randn(N,1)*sigmaAngle;

Angle = zeros(N,1);
%% get the simulated measurements

for i =1:N
    % get the angle measurement    
    if x==x1
        alpha0 = 0;
    elseif x >= x1 && y >= y1
        alpha0 = atan((y - y1)/(x - x1));
    elseif x < x1 && y > y1
        alpha0 = atan((y - y1)/(x - x1)) + pi;
    elseif x < x1 && y < y1
        alpha0 = atan((y - y1)/(x - x1)) + pi;
    elseif x > x1 && y < y1
        alpha0 = atan((y - y1)/(x - x1)) + 2*pi;
    end 
    Angle(i) = alpha0 + sigmaA(i);

end
angle = mean(Angle);

