clear global; clear variables;
%测量次数对定位误差的影响
%load anchor; 
%Anchor = anchor;
%m = length(Anchor);

m = 30;
Target = [50, 50];
sigmaDistance = 3;
sigmaAngle = 0.01;
sigmaDistance0 = 5;
sigmaAngle0 = 0.03;
N = 100;
NN = 100;

T=10;
R = 30;
Anchorx = zeros(R,1);
Anchory = zeros(R,1);
ErrorProposedAlg1 = ones(T,1);
LocationEstimation2=zeros(T,2);
ErrorProposedAlg2 = ones(T,1);
LocationEstimation3=zeros(T,2);
ErrorProposedAlg3 = ones(T,1); 
LocationEstimation4=zeros(T,2);
ErrorProposedAlg4 = ones(T,1); 

meanerror1=ones(10,NN);
meanerror2=ones(10,NN);
meanerror3=ones(10,NN);
meanerror4=ones(10,NN);

Error1 = zeros(m,NN);
Error2 = zeros(m,NN);
Error3 = zeros(m,NN);
Error4 = zeros(m,NN);
Anchor = rand(m,2)*100;
for k=1:NN
        Anchor1 = randi([1,30],1,3);
    for i=1:10
        Distance = zeros(m,i*10);
        Angle = zeros(m,i*10);
        Distance_w = zeros(1,i*10);
        Angle_w = zeros(1,i*10);
        for j = 1:m
            Anchor0 = Anchor(j,:);
            if ismember(j,Anchor1) == 0
                [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, i*10);
            else
                [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance0, sigmaAngle0, i*10);
            end
              Distance(j,:) = Distance0';%3行100列
              Angle(j,:) = Angle0';%3行100列
        end   
         Anchor_data = zeros(m,2);
         Anchor_quant_x = zeros(1,m);
         Anchor_quant_y = zeros(1,m);
         q_data_x = zeros(1,m);
         q_data_y = zeros(1,m);
         Anchor_x = zeros(m,10);
         Anchor_y = zeros(m,10);
        LocationEstimation1=zeros(20,2);
         %weight
          for t = 1:20
               q_x = 0;
               q_y = 0;
                for q = 1:m
                 for r = 1:R
                 if ismember(j,Anchor1) == 0
                     [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, i*10);
                 else
                     [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance0, sigmaAngle0, i*10);
                 end 
                   Distance_w(1,:) = Distance_r';
                   Angle_w(1,:) = Angle_r';
                   Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance_w(1,:), Angle_w(1,:));
                   if t == 1 
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(1,2);
                   end
                   if t > 1
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(t-1,1);
                      Anchory(r,1)=  Anchor_data(q,2) - LocationEstimation1(t-1,2);
                   end
                 end
                   Anchor_x(q,t) = mean(Anchorx);
                   Anchor_y(q,t) = mean(Anchory);
                    [Anchor_quant_x(1,q),q_data_x(1,q)] = quantize_clipping(Anchor_x(q,t),3,'SQE');
                    [Anchor_quant_y(1,q),q_data_y(1,q)] = quantize_clipping(Anchor_y(q,t),3,'SQE');
                    q_x = q_x + 1/q_data_x(1,q);
                    q_y = q_y + 1/q_data_y(1,q);
                end
                if t == 1
                   for q = 1:m
                      LocationEstimation1(1,1) = LocationEstimation1(1,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                      LocationEstimation1(1,2) = LocationEstimation1(1,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                   end
                end
                if t > 1
                   LocationEstimation1(t,1) = LocationEstimation1(t-1,1);
                   LocationEstimation1(t,2) = LocationEstimation1(t-1,2);
                    for q = 1:m
                         LocationEstimation1(t,1) = LocationEstimation1(t,1)+Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                         LocationEstimation1(t,2) = LocationEstimation1(t,2)+Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                    end
                end
          end
           ErrorProposedAlg1(i,:) = sqrt((Target(1,1) - LocationEstimation1(t,1))^2 + (Target(1,2) - LocationEstimation1(t,2))^2);
        
        [TargetTemp2] = PPProposedLocAlgorithm(Anchor, Distance, Angle);
        LocationEstimation2(i,:) = TargetTemp2;
        ErrorProposedAlg2(i,:)= sqrt((Target(1,1) - TargetTemp2(1,1))^2 + (Target(1,2) - TargetTemp2(1,2))^2);
        ErrorProposedAlg4(i,:)= sqrt((Target(1,1) - TargetTemp2(1,1))^2 + (Target(1,2) - TargetTemp2(1,2))^2);
        
        [TargetTemp3] = GPPADL(Anchor, Distance, Angle);
        LocationEstimation3(i,:) = TargetTemp3;
        % calculate the error
        ErrorProposedAlg3(i,:) = sqrt((Target(1,1) - TargetTemp3(1,1))^2 + (Target(1,2) - TargetTemp3(1,2))^2);

        % next how to record the results for 1000 runs; we can only record the
        % errors 
    end
    meanerror1(:,k)=ErrorProposedAlg1(:,1);
    meanerror2(:,k)=ErrorProposedAlg2(:,1);
    meanerror3(:,k)=ErrorProposedAlg3(:,1);
    meanerror4(:,k)=ErrorProposedAlg4(:,1);
end
meanerror1 = meanerror1';
Err1 = mean(meanerror1);
meanerror2 = meanerror2';
Err2 = mean(meanerror2);
meanerror3 = meanerror3';
Err3 = mean(meanerror3);
meanerror4 = meanerror4';
Err4 = mean(meanerror4);
figure(1);
plot((100:100:1000),Err1,'r-o','MarkerSize',8,'LineWidth',1.5)
hold on
plot((100:100:1000),Err4,'k-s','MarkerSize',8,'LineWidth',1.5)
hold on
plot((100:100:1000),Err2,'c-+','MarkerSize',8,'LineWidth',1.5)
hold on
plot((100:100:1000),Err3,'g->','MarkerSize',8,'LineWidth',1.5)

%ylim([0,1]);

legend('\fontsize{14} QPPL','\fontsize{14} HPPL','\fontsize{14} ZPPL','\fontsize{14} GPPL');
xlabel({'Number of Measurements '},'FontSize',14);
ylabel({'Location Error (meters)'},'FontSize',14);