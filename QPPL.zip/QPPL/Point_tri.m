
vertex(1,:) = [3,10];
vertex(2,:) = [50,94];
vertex(3,:) = [95,73];
% 示例使用
n = 30; % 生成100个点

% 调用函数生成点
randomPoints = generateRandomPointsInTriangle(n, vertex(1,:), vertex(2,:), vertex(3,:));
randomPoints1 = generateNonUniformRandomPointsInTriangle(n, vertex(1,:), vertex(2,:), vertex(3,:));

% 绘制三角形和随机点
figure;
hold on;
plot([vertex(1,1),vertex(2,1),vertex(3,1),vertex(1,1)], [vertex(1,2),vertex(2,2),vertex(3,2),vertex(1,2)], 'k-', 'LineWidth', 2); % 绘制三角形
plot(randomPoints(:, 1), randomPoints(:, 2), 'ro'); % 绘制随机点
plot(randomPoints1(:, 1), randomPoints1(:, 2), 'bo');
plot([30,70], [58.26,70], 'c+','LineWidth', 2,'MarkerSize', 13);
text(28, 58.26, 't1' ,'HorizontalAlignment', 'right','FontSize', 15);
text(70, 65, 't2' ,'HorizontalAlignment', 'left','FontSize', 15);
set(gca,'xtick',(0:10:100));
xlim([0, 100]);
set(gca,'ytick',(0:10:100));
ylim([0, 100]);
%axis equal;
xlabel('X');
ylabel('Y');
%title('Random Points in a Triangle');
hold off;