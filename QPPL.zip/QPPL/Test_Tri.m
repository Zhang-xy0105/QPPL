clear global; clear variables;
m = 30;

sigmaDistance = 3;
sigmaAngle = 0.01;
sigmaDistance0 =5;
sigmaAngle0 = 0.03;
load('matlab.mat', 'randomPoints');
load('matlab1.mat', 'randomPoints1');
Target1=[30,58.26];
Target2=[70,70];
N = 1000; % the number of the measurements
NN = 10; % the number of runs to reduce the randomness
Error1 = zeros(m/3,N);
Error2 = zeros(m/3,N);
Error3 = zeros(m/3,N);
Error4 = zeros(m/3,N);
%Error4 = zeros(m/3,NN);
%Error5 = zeros(m/3,NN);
R = 10;
%Anchorr1 = zeros(R,1);
%Anchorr2 = zeros(R,1);
Anchorx = zeros(R,1);
Anchory = zeros(R,1);
Anchorx1 = zeros(R,1);
Anchory1 = zeros(R,1);
Anchorx2 = zeros(R,1);
Anchory2 = zeros(R,1);
Anchorx3 = zeros(R,1);
Anchory3 = zeros(R,1);
%LocationEstimation4 = zeros(m/3,2);
%ErrorProposedAlg4 = zeros(m/3,1); 
% %     Distance = zeros(m,NN);
% %     Angle = zeros(m,NN);
%     Distance_w = zeros(1,NN);
%     Angle_w = zeros(1,NN);
% %     Distance1 = zeros(m,NN);
% %     Angle1 = zeros(m,NN);
%     Distance_w1 = zeros(1,NN);
%     Angle_w1 = zeros(1,NN);
% %     Distance2 = zeros(m,NN);
% %     Angle2 = zeros(m,NN);
%     Distance_w2 = zeros(1,NN);
%     Angle_w2 = zeros(1,NN);
% %         Distance3 = zeros(m,NN);
% %     Angle3 = zeros(m,NN);
%     Distance_w3 = zeros(1,NN);
%     Angle_w3 = zeros(1,NN);
for i = 1:N
           Anchor1 = randi([1,30],1,3);
           
           ErrorProposedAlg3 = zeros(m/3,1);
           ErrorProposedAlg1 = zeros(m/3,1);
           %LocationEstimation2 = zeros(m/3,2);
           ErrorProposedAlg2 = zeros(m/3,1); 
    
           %LocationEstimation3 = zeros(m/3,2);
           ErrorProposedAlg4 = zeros(m/3,1); 
     for c = 1:10
%     for n = 1:m
%         Anchor0 = randomPoints(n,:);
%         if ismember(n,Anchor1) == 0
%             [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target1, sigmaDistance, sigmaAngle, c*10);
%         else
%            [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target1, sigmaDistance0, sigmaAngle0, c*10);
%         end
%        Distance(n,:) = Distance0';
%        Angle(n,:) = Angle0';
%     end
     % for j = 1:m
         Distance_w = zeros(1,c*NN);
         Angle_w = zeros(1,c*NN);
         Distance_w1 = zeros(1,c*NN);
         Angle_w1 = zeros(1,c*NN);
         Distance_w2 = zeros(1,c*NN);
         Angle_w2 = zeros(1,c*NN);
         Distance_w3 = zeros(1,c*NN);
         Angle_w3 = zeros(1,c*NN);
          Anchor_data = zeros(m,2);
          Anchor_data1 = zeros(m,2);
          Anchor_data2 = zeros(m,2);
          Anchor_data3 = zeros(m,2);
          Anchor_quant_x = zeros(1,m);
          Anchor_quant_y = zeros(1,m);
          Anchor_quant_x1 = zeros(1,m);
          Anchor_quant_y1 = zeros(1,m);
          Anchor_quant_x2 = zeros(1,m);
          Anchor_quant_y2 = zeros(1,m);
          Anchor_quant_x3 = zeros(1,m);
          Anchor_quant_y3 = zeros(1,m);
          q_data_x = zeros(1,m); 
          q_data_y = zeros(1,m);
          q_data_x1 = zeros(1,m); 
          q_data_y1 = zeros(1,m);
          q_data_x2 = zeros(1,m); 
          q_data_y2 = zeros(1,m);
          q_data_x3 = zeros(1,m); 
          q_data_y3 = zeros(1,m);
%           Anchor_x = zeros(m,10);
%           Anchor_y = zeros(m,10);
          LocationEstimation1 = zeros(10,2);
          LocationEstimation2 = zeros(10,2);
          LocationEstimation3 = zeros(10,2);
          LocationEstimation4 = zeros(10,2);
          %LocationEstimation5 = zeros(10,2);
          for t = 1:10
               q_x = 0;
               q_y = 0;
               q_x1 = 0;
               q_y1 = 0;
               q_x2 = 0;
               q_y2 = 0;
               q_x3 = 0;
               q_y3 = 0;
                for q = 1:m
                 for r = 1:R
                  if ismember(q,Anchor1) == 0
                           [distance_w,angle_w] = GetMeasurementForEachAnchor(randomPoints(q,:), Target1, sigmaDistance, sigmaAngle, c*NN);
                           [distance_w1,angle_w1] = GetMeasurementForEachAnchor(randomPoints(q,:), Target2, sigmaDistance, sigmaAngle, c*NN);
                           [distance_w2,angle_w2] = GetMeasurementForEachAnchor(randomPoints1(q,:), Target1, sigmaDistance, sigmaAngle, c*NN);
                           [distance_w3,angle_w3] = GetMeasurementForEachAnchor(randomPoints1(q,:), Target2, sigmaDistance, sigmaAngle, c*NN);
                  else                                                                                 
                           [distance_w,angle_w] = GetMeasurementForEachAnchor(randomPoints(q,:), Target1, sigmaDistance0, sigmaAngle0, c*NN);
                           [distance_w1,angle_w1] = GetMeasurementForEachAnchor(randomPoints(q,:), Target2, sigmaDistance0, sigmaAngle0, c*NN);
                           [distance_w2,angle_w2] = GetMeasurementForEachAnchor(randomPoints1(q,:), Target1, sigmaDistance0, sigmaAngle0, c*NN);
                           [distance_w3,angle_w3] = GetMeasurementForEachAnchor(randomPoints1(q,:), Target2, sigmaDistance0, sigmaAngle0, c*NN);
                  end
                      Distance_w(1,:) = distance_w';
                      Angle_w(1,:) = angle_w';
                      Distance_w1(1,:) = distance_w1';
                      Angle_w1(1,:) = angle_w1';
                      Distance_w2(1,:) = distance_w2';
                      Angle_w2(1,:) = angle_w2';
                      Distance_w3(1,:) = distance_w3';
                      Angle_w3(1,:) = angle_w3';
                      Anchor_data(q,:) = ProposedLocAlgorithm(randomPoints(q,:), Distance_w(1,:), Angle_w(1,:));
                      Anchor_data1(q,:) = ProposedLocAlgorithm(randomPoints(q,:), Distance_w1(1,:), Angle_w1(1,:));
                      Anchor_data2(q,:) = ProposedLocAlgorithm(randomPoints1(q,:), Distance_w2(1,:), Angle_w2(1,:));
                      Anchor_data3(q,:) = ProposedLocAlgorithm(randomPoints1(q,:), Distance_w3(1,:), Angle_w3(1,:));
                   if t == 1 
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(1,2);
                      Anchorx1(r,1) =  Anchor_data1(q,1) - LocationEstimation2(1,1);
                      Anchory1(r,1) =  Anchor_data1(q,2) - LocationEstimation2(1,2);
                      Anchorx2(r,1) =  Anchor_data2(q,1) - LocationEstimation3(1,1);
                      Anchory2(r,1) =  Anchor_data2(q,2) - LocationEstimation3(1,2);
                      Anchorx3(r,1) =  Anchor_data3(q,1) - LocationEstimation4(1,1);
                      Anchory3(r,1) =  Anchor_data3(q,2) - LocationEstimation4(1,2);
                   end
                 
                   if t > 1
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(t-1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(t-1,2);
                      Anchorx1(r,1) =  Anchor_data1(q,1) - LocationEstimation2(t-1,1);
                      Anchory1(r,1) =  Anchor_data1(q,2) - LocationEstimation2(t-1,2);
                      Anchorx2(r,1) =  Anchor_data2(q,1) - LocationEstimation3(t-1,1);
                      Anchory2(r,1) =  Anchor_data2(q,2) - LocationEstimation3(t-1,2);
                      Anchorx3(r,1) =  Anchor_data3(q,1) - LocationEstimation4(t-1,1);
                      Anchory3(r,1) =  Anchor_data3(q,2) - LocationEstimation4(t-1,2);
                   end
                 end
                  % Anchor_x(q,t) = mean(Anchorx);
                  % Anchor_y(q,t) = mean(Anchory);
                   if q<=0.3*m
                      [anchorx,q_data_x(1,q)] = quantize_clipping(Anchorx,5,'SQE');
                      [anchory,q_data_y(1,q)] = quantize_clipping(Anchory,5,'SQE');
                      [anchorx1,q_data_x1(1,q)] = quantize_clipping(Anchorx1,5,'SQE');
                      [anchory1,q_data_y1(1,q)] = quantize_clipping(Anchory1,5,'SQE');
                      [anchorx2,q_data_x2(1,q)] = quantize_clipping(Anchorx2,5,'SQE');
                      [anchory2,q_data_y2(1,q)] = quantize_clipping(Anchory2,5,'SQE');
                      [anchorx3,q_data_x3(1,q)] = quantize_clipping(Anchorx3,5,'SQE');
                      [anchory3,q_data_y3(1,q)] = quantize_clipping(Anchory3,5,'SQE');
                   else
                      [anchorx,q_data_x(1,q)] = quantize_clipping(Anchorx,3,'SQE');
                      [anchory,q_data_y(1,q)] = quantize_clipping(Anchory,3,'SQE');
                      [anchorx1,q_data_x1(1,q)] = quantize_clipping(Anchorx1,3,'SQE');
                      [anchory1,q_data_y1(1,q)] = quantize_clipping(Anchory1,3,'SQE');
                      [anchorx2,q_data_x2(1,q)] = quantize_clipping(Anchorx2,3,'SQE');
                      [anchory2,q_data_y2(1,q)] = quantize_clipping(Anchory2,3,'SQE');
                      [anchorx3,q_data_x3(1,q)] = quantize_clipping(Anchorx3,3,'SQE');
                      [anchory3,q_data_y3(1,q)] = quantize_clipping(Anchory3,3,'SQE');
                   end
                  % Anchorr1 = Anchorr1';
                  % Anchorr2 = Anchorr2';
                   Anchor_quant_x(1,q) = mean(anchorx);
                   Anchor_quant_y(1,q) = mean(anchory);
                   Anchor_quant_x1(1,q) = mean(anchorx1);
                   Anchor_quant_y1(1,q) = mean(anchory1);
                   Anchor_quant_x2(1,q) = mean(anchorx2);
                   Anchor_quant_y2(1,q) = mean(anchory2);
                   Anchor_quant_x3(1,q) = mean(anchorx3);
                   Anchor_quant_y3(1,q) = mean(anchory3);
                    q_x = q_x + 1/q_data_x(1,q);
                    q_y = q_y + 1/q_data_y(1,q);
                    q_x1 = q_x1 + 1/q_data_x1(1,q);
                    q_y1 = q_y1 + 1/q_data_y1(1,q);
                    q_x2 = q_x2 + 1/q_data_x2(1,q);
                    q_y2 = q_y2 + 1/q_data_y2(1,q);
                    q_x3 = q_x3 + 1/q_data_x3(1,q);
                    q_y3 = q_y3 + 1/q_data_y3(1,q);
                   % Anchorx = Anchorx';
                    %Anchory = Anchory';

%                       Anchor_data(q,:) = ProposedLocAlgorithm(randomPoints(q,:), Distance_w(1,:), Angle_w(1,:));
%                       Anchor_data1(q,:) = ProposedLocAlgorithm(randomPoints(q,:), Distance_w1(1,:), Angle_w1(1,:));
%                       Anchor_data2(q,:) = ProposedLocAlgorithm(randomPoints1(q,:), Distance_w2(1,:), Angle_w2(1,:));
%                       Anchor_data3(q,:) = ProposedLocAlgorithm(randomPoints1(q,:), Distance_w3(1,:), Angle_w3(1,:));
               
                end
                if t == 1
                   for q = 1:m
                      LocationEstimation1(1,1) = LocationEstimation1(1,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                      LocationEstimation1(1,2) = LocationEstimation1(1,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                      LocationEstimation2(1,1) = LocationEstimation2(1,1)+ Anchor_quant_x1(1,q) * ((1/q_data_x1(1,q)) / q_x1);
                      LocationEstimation2(1,2) = LocationEstimation2(1,2)+ Anchor_quant_y1(1,q) * ((1/q_data_y1(1,q)) / q_y1);
                      LocationEstimation3(1,1) = LocationEstimation3(1,1)+ Anchor_quant_x2(1,q) * ((1/q_data_x2(1,q)) / q_x2);
                      LocationEstimation3(1,2) = LocationEstimation3(1,2)+ Anchor_quant_y2(1,q) * ((1/q_data_y2(1,q)) / q_y2);
                      LocationEstimation4(1,1) = LocationEstimation4(1,1)+ Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
                      LocationEstimation4(1,2) = LocationEstimation4(1,2)+ Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);

                   end
                end
                if t > 1
                     LocationEstimation1(t,1) = LocationEstimation1(t-1,1);
                     LocationEstimation1(t,2) = LocationEstimation1(t-1,2);
                     LocationEstimation2(t,1) = LocationEstimation2(t-1,1);
                     LocationEstimation2(t,2) = LocationEstimation2(t-1,2);
                     LocationEstimation3(t,1) = LocationEstimation3(t-1,1);
                     LocationEstimation3(t,2) = LocationEstimation3(t-1,2);
                     LocationEstimation4(t,1) = LocationEstimation4(t-1,1);
                     LocationEstimation4(t,2) = LocationEstimation4(t-1,2);
                    for q = 1:m
                         LocationEstimation1(t,1) = LocationEstimation1(t,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                         LocationEstimation1(t,2) = LocationEstimation1(t,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                         LocationEstimation2(t,1) = LocationEstimation2(t,1)+ Anchor_quant_x1(1,q) * ((1/q_data_x1(1,q)) / q_x1);
                         LocationEstimation2(t,2) = LocationEstimation2(t,2)+ Anchor_quant_y1(1,q) * ((1/q_data_y1(1,q)) / q_y1);
                         LocationEstimation3(t,1) = LocationEstimation3(t,1)+ Anchor_quant_x2(1,q) * ((1/q_data_x2(1,q)) / q_x2);
                         LocationEstimation3(t,2) = LocationEstimation3(t,2)+ Anchor_quant_y2(1,q) * ((1/q_data_y2(1,q)) / q_y2);
                         LocationEstimation4(t,1) = LocationEstimation4(t,1)+ Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
                         LocationEstimation4(t,2) = LocationEstimation4(t,2)+ Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
                   %   LocationEstimation5(t,1) = LocationEstimation5(t,1)+ Anchorx1(1,q) * 1/(j*3);
                   %   LocationEstimation5(t,2) = LocationEstimation5(t,2)+ Anchory1(1,q) * 1/(j*3);
                    end
                end
          end
           ErrorProposedAlg1(c,:) = sqrt((Target1(1,1) - LocationEstimation1(t,1))^2 + (Target1(1,2) - LocationEstimation1(t,2))^2); 
           ErrorProposedAlg2(c,:) = sqrt((Target2(1,1) - LocationEstimation2(t,1))^2 + (Target2(1,2) - LocationEstimation2(t,2))^2);
           ErrorProposedAlg3(c,:) = sqrt((Target1(1,1) - LocationEstimation3(t,1))^2 + (Target1(1,2) - LocationEstimation3(t,2))^2);
           ErrorProposedAlg4(c,:) = sqrt((Target2(1,1) - LocationEstimation4(t,1))^2 + (Target2(1,2) - LocationEstimation4(t,2))^2);
     % end
      end

      
         Error1(:,i) = ErrorProposedAlg1(:,1);
         Error2(:,i) = ErrorProposedAlg2(:,1);
         Error3(:,i) = ErrorProposedAlg3(:,1);
         Error4(:,i) = ErrorProposedAlg4(:,1);
       % Error5(:,i) = ErrorProposedAlg5(:,1);
 
end

Error1 = Error1';
Err1 = mean(Error1);

Error2 = Error2';
Err2 = mean(Error2);

Error3 = Error3';
Err3 = mean(Error3);

Error4 = Error4';
Err4 = mean(Error4);
%Err2(1,1)=NaN;
figure(1);
set(gca,'xtick',(3:3:30));
plot((1000:1000:10000),Err1,'r-x','MarkerSize',8,'LineWidth',1.5)  
hold on
plot((1000:1000:10000),Err2,'m-x','MarkerSize',8,'LineWidth',1.5)
hold on
%plot((3:3:30),Err4,'c-+','MarkerSize',8,'LineWidth',1.5)
%hold on
plot((1000:1000:10000),Err3,'b-x','MarkerSize',8,'LineWidth',1.5)
hold on
plot((1000:1000:10000),Err4,'g-x','MarkerSize',8,'LineWidth',1.5)
%plot((3:3:30),Err5,'m->','MarkerSize',8,'LineWidth',1.5)
set(gca,'xtick',(1000:1000:10000));
xlim([1000, 10000]);
%set(gca,'xtick',3:2:20);
legend('\fontsize{15} t1 uniform','\fontsize{15} t2 uniform','\fontsize{15} t1 non-uniform','\fontsize{15} t2 non-uniform')
xlabel({'Number of Measurements'},'FontSize',14);
ylabel({'Location Error (meters)'},'FontSize',14);
hold off

