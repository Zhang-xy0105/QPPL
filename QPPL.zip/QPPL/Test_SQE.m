clear global; clear variables;
%真实数据实验
%load anchor; 
%Anchor = anchor;
%m = length(Anchor);
load RealDATA;
Target = [50, 50];
m = 30;
N = 1;
NN = 100;
Anchor = zeros(m,2);
Distance = zeros(1,NN);
Angle = zeros(1,NN);

sigmaDistance = 3;
sigmaAngle = 0.01;
sigmaDistance1 = 5;
sigmaAngle1 = 0.03;
%LocationEstimation = zeros(N,2);
ErrorProposedAlg = zeros(10,1);
%LocationEstimation1 = zeros(N,2);
ErrorProposedAlg1 = zeros(10,1);
%LocationEstimation2 = zeros(N,2);
ErrorProposedAlg2 = zeros(10,1);
LocationEstimation3 = zeros(N,2);
ErrorProposedAlg3 = zeros(N,1);
Anchor_data = zeros(10,2);
Anchor_data1 = zeros(10,2);
Anchor_data2 = zeros(10,2);
Anchor_data3 = zeros(N,2);
Anchor_quant_x = zeros(1,m);
Anchor_quant_y = zeros(1,m);
Anchor_quant_x1 = zeros(1,m);
Anchor_quant_y1 = zeros(1,m);
Anchor_quant_x2 = zeros(1,m);
Anchor_quant_y2 = zeros(1,m);
Anchor_quant_x3 = zeros(1,m);
Anchor_quant_y3 = zeros(1,m);
q_data_x = zeros(10,m);
q_data_y = zeros(10,m);
q_data_x1 = zeros(10,m);
q_data_y1 = zeros(10,m);
q_data_x2 = zeros(1,m);
q_data_y2 = zeros(1,m);
q_data_x3 = zeros(1,m);
q_data_y3 = zeros(1,m);
Anchor_x = zeros(m,10);
Anchor_y = zeros(m,10);
Anchor_x1 = zeros(m,10);
Anchor_y1 = zeros(m,10);
Anchor_x2 = zeros(m,10);
Anchor_y2 = zeros(m,10);
Anchor_x3 = zeros(m,10);
Anchor_y3 = zeros(m,10);
weight = zeros(10,m);
weight1 = zeros(10,m);
mean_Sqe = zeros(10,N);
mean_Sqe1 = zeros(10,N);

for q = 1:30
    Anchor(q,:)= RealDATA(q,:);
end
meanerror=zeros(10,1);
meanerror1=zeros(10,1);
meanerror2=zeros(10,1);
meanerror3=zeros(10,1);
Error = zeros(10,N);
Error1 = zeros(10,N);
Error2 = zeros(10,N);
Error3 = zeros(10,N);
for a = 1:N
    Anchor1 = randi([1,30],1,3);
    Sqe_x = zeros(10,1);
    Sqe_x1 = zeros(10,1);
    Sqe_y = zeros(10,1);
    Sqe_y1 = zeros(10,1);
    LocationEstimation = zeros(10,2);
    LocationEstimation1 = zeros(10,2);
    %LocationEstimation2 = zeros(N,2);
for k = 1:10
   for i = 1*k
      % P = 0;
        q_x = 0;
        q_y = 0;
        q_x1 = 0;
        q_y1 = 0;
       % q_x2 = 0;
      %  q_y2 = 0;
        %q_x3 = 0;
        %q_y3 = 0;
        for q = 1:m
            if ismember(q,Anchor1) == 0
                [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
            else
                [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance1, sigmaAngle1, NN);
            end
       % [Distance_r,Angle_r] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
        Distance(1,:) = Distance_r';
        Angle(1,:) = Angle_r';
          Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance(1,:), Angle(1,:));
        %    S=rand(1,50);
               %   for n=1:1
                  %    S(n,:)=S(n,:)/sum(S(n,:));
                 % end
         if i == 1 

          Anchor_x(q,i) =  Anchor_data(q,1) - LocationEstimation(1,1);
          Anchor_y(q,i) =  Anchor_data(q,2) - LocationEstimation(1,2);
          Anchor_x1(q,i) =  Anchor_data(q,1) - LocationEstimation1(1,1);
          Anchor_y1(q,i) =  Anchor_data(q,2) - LocationEstimation1(1,2);
         % Anchor_x2(q,i) =  Anchor_data(q,1) - LocationEstimation2(1,1);
          %Anchor_y2(q,i) =  Anchor_data(q,2) - LocationEstimation2(1,2);
          %Anchor_x3(q,i) =  Anchor_data(q,1) - LocationEstimation3(1,1);
          %Anchor_y3(q,i) =  Anchor_data(q,2) - LocationEstimation3(1,2);
         end
         if i > 1
          Anchor_x(q,i) =  Anchor_data(q,1) - LocationEstimation(i-1,1);
          Anchor_y (q,i)=  Anchor_data(q,2) - LocationEstimation(i-1,2);
          Anchor_x1(q,i) =  Anchor_data(q,1) - LocationEstimation1(i-1,1);
          Anchor_y1(q,i) =  Anchor_data(q,2) - LocationEstimation1(i-1,2);
          %Anchor_x2(q,i) =  Anchor_data(q,1) - LocationEstimation2(i-1,1);
          %Anchor_y2(q,i) =  Anchor_data(q,2) - LocationEstimation2(i-1,2);
          %Anchor_x3(q,i) =  Anchor_data(q,1) - LocationEstimation3(i-1,1);
          %Anchor_y3(q,i) =  Anchor_data(q,2) - LocationEstimation3(i-1,2);
         end
         %bit=4
         if q<=0.2*m
                    [Anchor_quant_x(1,q),q_data_x(i,q)] = quantize_clipping(Anchor_x(q,i),5,'SQE');
                    [Anchor_quant_y(1,q),q_data_y(i,q)] = quantize_clipping(Anchor_y(q,i),5,'SQE');
                    [Anchor_quant_x1(1,q),q_data_x1(i,q)] = quantize_clipping(Anchor_x1(q,i),5,'SQE');
                    [Anchor_quant_y1(1,q),q_data_y1(i,q)] = quantize_clipping(Anchor_y1(q,i),5,'SQE');
                    %[Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),5,'SQE');
                    %[Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),5,'SQE');
                    
                    
         else
                    [Anchor_quant_x(1,q),q_data_x(i,q)] = quantize_clipping(Anchor_x(q,i),3,'SQE');
                    [Anchor_quant_y(1,q),q_data_y(i,q)] = quantize_clipping(Anchor_y(q,i),3,'SQE');
                    [Anchor_quant_x1(1,q),q_data_x1(i,q)] = quantize_clipping(Anchor_x1(q,i),3,'SQE');
                    [Anchor_quant_y1(1,q),q_data_y1(i,q)] = quantize_clipping(Anchor_y1(q,i),3,'SQE');
                   % [Anchor_quant_x2(1,q),q_data_x2(1,q)] = quantize_clipping(Anchor_x2(q,i),3,'SQE');
                   % [Anchor_quant_y2(1,q),q_data_y2(1,q)] = quantize_clipping(Anchor_y2(q,i),3,'SQE');
         end
          q_x = q_x + 1/q_data_x(i,q);
          q_y = q_y + 1/q_data_y(i,q);
          
          q_x1 = q_x1 + 1/q_data_x1(i,q);
          q_y1 = q_y1 + 1/q_data_y1(i,q);
          
          
         % q_x2 = q_x2 + 1/q_data_x2(1,q);
        %  q_y2 = q_y2 + 1/q_data_y2(1,q);
          
        %  [Anchor_quant_x3(1,q),q_data_x3(1,q)] = quantize_clipping(Anchor_x3(q,i),3,'SQE');
         % [Anchor_quant_y3(1,q),q_data_y3(1,q)] = quantize_clipping(Anchor_y3(q,i),3,'SQE');
         % q_x3 = q_x3 + 1/q_data_x3(1,q);
         % q_y3 = q_y3 + 1/q_data_y3(1,q);

 
         %Sqe_x1(k,:) =Sqe_x1(k,:)+ q_data_x1(i,q)*1/m;
        end

        
        if i == 1
            for q = 1:m
                LocationEstimation(1,1) = LocationEstimation(1,1)+Anchor_quant_x(1,q) * ((1/q_data_x(i,q)) / q_x);
                LocationEstimation(1,2) = LocationEstimation(1,2)+Anchor_quant_y(1,q) * ((1/q_data_y(i,q)) / q_y);
                LocationEstimation1(1,1) = LocationEstimation1(1,1)+Anchor_quant_x1(1,q) * 1/m;
                LocationEstimation1(1,2) = LocationEstimation1(1,2)+Anchor_quant_y1(1,q) * 1/m;
               % LocationEstimation2(1,1) = LocationEstimation2(1,1)+Anchor_quant_x2(1,q) * S(1,q);
               % LocationEstimation2(1,2) = LocationEstimation2(1,2)+Anchor_quant_y2(1,q) * S(1,q);
               % LocationEstimation3(1,1) = LocationEstimation3(1,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
              %  LocationEstimation3(1,2) = LocationEstimation3(1,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
              weight(i,q) = (1/q_data_x(i,q)) / q_x;

              Sqe_x(k,:) =Sqe_x(k,:)+ sqrt(q_data_x(i,q))*((1/q_data_x(i,q)) / q_x);
              Sqe_x1(k,:) =Sqe_x1(k,:)+ sqrt(q_data_x1(i,q))*1/m;
               Sqe_y(k,:) =Sqe_y(k,:)+ sqrt(q_data_y(i,q))*((1/q_data_y(i,q)) / q_y);
              Sqe_y1(k,:) =Sqe_y1(k,:)+ sqrt(q_data_y1(i,q))*1/m;
            end  
        end
        if i > 1
            LocationEstimation(i,1) = LocationEstimation(i-1,1);
            LocationEstimation(i,2) = LocationEstimation(i-1,2);
            LocationEstimation1(i,1) = LocationEstimation1(i-1,1);
            LocationEstimation1(i,2) = LocationEstimation1(i-1,2);
           % LocationEstimation2(i,1) = LocationEstimation2(i-1,1);
          %  LocationEstimation2(i,2) = LocationEstimation2(i-1,2);
         %   LocationEstimation3(i,1) = LocationEstimation3(i-1,1);
          %  LocationEstimation3(i,2) = LocationEstimation3(i-1,2);
             for q = 1:m
                LocationEstimation(i,1) = LocationEstimation(i,1)+Anchor_quant_x(1,q) * ((1/q_data_x(i,q)) / q_x);
                LocationEstimation(i,2) = LocationEstimation(i,2)+Anchor_quant_y(1,q) * ((1/q_data_y(i,q)) / q_y);
                LocationEstimation1(i,1) = LocationEstimation1(i,1)+Anchor_quant_x1(1,q) * 1/m;
                LocationEstimation1(i,2) = LocationEstimation1(i,2)+Anchor_quant_y1(1,q) * 1/m;
                weight(i,q) = (1/q_data_x(i,q)) / q_x;
                Sqe_x(k,:) =Sqe_x(k,:)+ sqrt(q_data_x(i,q))*((1/q_data_x(i,q)) / q_x);
                Sqe_x1(k,:) =Sqe_x1(k,:)+ sqrt(q_data_x1(i,q))*1/m;
               Sqe_y(k,:) =Sqe_y(k,:)+ sqrt(q_data_y(i,q))*((1/q_data_y(i,q)) / q_y);
               Sqe_y1(k,:) =Sqe_y1(k,:)+ sqrt(q_data_y1(i,q))*1/m;
                
                %LocationEstimation2(i,1) = LocationEstimation2(i,1)+Anchor_quant_x2(1,q) * S(1,q);
               % LocationEstimation2(i,2) = LocationEstimation2(i,2)+Anchor_quant_y2(1,q) * S(1,q);
               % LocationEstimation3(i,1) = LocationEstimation3(i,1)+Anchor_quant_x3(1,q) * ((1/q_data_x3(1,q)) / q_x3);
               % LocationEstimation3(i,2) = LocationEstimation3(i,2)+Anchor_quant_y3(1,q) * ((1/q_data_y3(1,q)) / q_y3);
            end  
        end
        ErrorProposedAlg(i,:) = sqrt((Target(1,1) - LocationEstimation(i,1))^2 + (Target(1,2) - LocationEstimation(i,2))^2);
        ErrorProposedAlg1(i,:) = sqrt((Target(1,1) - LocationEstimation1(i,1))^2 + (Target(1,2) - LocationEstimation1(i,2))^2);
        %ErrorProposedAlg2(i,:) = sqrt((Target(1,1) - LocationEstimation2(i,1))^2 + (Target(1,2) - LocationEstimation2(i,2))^2);
       % ErrorProposedAlg3(i,:) = sqrt((Target(1,1) - LocationEstimation3(i,1))^2 + (Target(1,2) - LocationEstimation3(i,2))^2);
        if k<10
          Sqe_x(k+1,:) = Sqe_x(k,:);
          Sqe_x1(k+1,:) = Sqe_x1(k,:);
          Sqe_y(k+1,:) = Sqe_y(k,:);
          Sqe_y1(k+1,:) = Sqe_y1(k,:);
        end
   end
      meanerror(k,:)=ErrorProposedAlg(i,:);
      meanerror1(k,:)=ErrorProposedAlg1(i,:);
     % meanerror2(k,:)=ErrorProposedAlg2(i,:);
     % meanerror3(k,:)=ErrorProposedAlg3(i,:);
end
     mean_Sqe(:,a) = Sqe_x(:,1);
     mean_Sqe(:,a+1) = Sqe_y(:,1);
     mean_Sqe1(:,a) = Sqe_x1(:,1);
     mean_Sqe1(:,a+1) = Sqe_y1(:,1);
     Error(:,a) = meanerror(:,1);
     Error1(:,a) = meanerror1(:,1);
    % Error2(:,a) = meanerror2(:,1);
    % Error3(:,a) = meanerror3(:,1);
end

Error = Error';
Error1 = Error1';
Error2 = Error2';
Err = mean(Error);
Err1 = mean(Error1);
Err2 = mean(Error2);
%Err3 = mean(Error3);
mean_Sqe = mean_Sqe';
mean_Sqe1 = mean_Sqe1';
Sqe = mean(mean_Sqe);
Sqe1 = mean(mean_Sqe1);
figure(1);

X1=plot((1:1:10),mean_Sqe,'r-o','MarkerSize',8,'LineWidth',1.5);
hold on
X2=plot((1:1:10),mean_Sqe1,'b-d','MarkerSize',8,'LineWidth',1.5);
%plot((1:1:10),Err2,'g-x','MarkerSize',8,'LineWidth',1.5)
%plot((1:1:10),Err3,'b-*','MarkerSize',8,'LineWidth',1.5)
legend([X1(1),X2(1)],'QPPL','E-QAL','FontSize',15);
xlabel({'Iterations '},'FontSize',14);
ylabel({'SQE weighted sum'},'FontSize',14);
