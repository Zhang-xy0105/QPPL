clear global; clear variables;
load('HPPLtime.mat', 'Err2');
m = 30;
Target = [50, 50];
sigmaDistance = 5;
sigmaAngle = 0.03;
sigmaDistance0 =3;
sigmaAngle0 = 0.01;
sigmaDistance1 =2;
sigmaAngle1 = 0.01;
N = 1000; % the number of the measurements
NN = 3; % the number of runs to reduce the randomness
Error1 = zeros(m/3,NN);
Error2 = zeros(m/3,NN);
Error3 = zeros(m/3,NN);
%Error4 = zeros(m/3,NN);
%Error5 = zeros(m/3,NN);
R = 30;
%Anchorr1 = zeros(R,1);
%Anchorr2 = zeros(R,1);
Anchorx = zeros(R,1);
Anchory = zeros(R,1);
Anchorx3 = zeros(R,1);
Anchory3 = zeros(R,1);
Anchorx2 = zeros(R,1);
Anchory2 = zeros(R,1);
%LocationEstimation4 = zeros(m/3,2);
%ErrorProposedAlg4 = zeros(m/3,1); 


    Anchor = rand(m,2)*100;
    Anchor2 = rand(m,2)*1000;
    Anchor3 = rand(m,2)*10000;
    Distance = zeros(m,NN);
    Angle = zeros(m,NN);
    Distance_w = zeros(1,NN);
    Angle_w = zeros(1,NN);
    Distance1 = zeros(m,NN);
    Angle1 = zeros(m,NN);
    Distance_w1 = zeros(1,NN);
    Angle_w1 = zeros(1,NN);
    Distance2 = zeros(m,NN);
    Angle2 = zeros(m,NN);
    Distance_w2 = zeros(1,NN);
    Angle_w2 = zeros(1,NN);
    RT1= zeros(m/3,NN);
    RT2= zeros(m/3,NN);
for i = 1:NN
          Anchor1 = randi([1,30],1,3);
          Runningtime1 = zeros(m/3,1);
        Runningtime2 = zeros(m/3,1);
           ErrorProposedAlg1 = zeros(m/3,1);
           %LocationEstimation2 = zeros(m/3,2);
           ErrorProposedAlg2 = zeros(m/3,1); 
    
           LocationEstimation3 = zeros(m/3,2);
           ErrorProposedAlg3 = zeros(m/3,1); 
    tic;           
   for n = 1:m
        Anchor0 = Anchor(n,:);
        if ismember(n,Anchor1) == 0
            [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance, sigmaAngle, NN);
        else
           [Distance0,Angle0] = GetMeasurementForEachAnchor(Anchor0, Target, sigmaDistance0, sigmaAngle0, NN);
        end
       Distance(n,:) = Distance0';
       Angle(n,:) = Angle0';
   end
          PPADL=toc;

      for j = 1:(m/3)
           tic;
          Anchor_data = zeros(j*3,2);
          Anchor_quant_x = zeros(1,j*3);
          Anchor_quant_y = zeros(1,j*3);
          
          Anchorx1 = zeros(1,j*3);
          Anchory1 = zeros(1,j*3);
          q_data_x = zeros(1,j*3); 
          q_data_y = zeros(1,j*3);
          Anchor_x = zeros(j*3,20);
          Anchor_y = zeros(j*3,20);
          LocationEstimation1 = zeros(10,2);
          %LocationEstimation5 = zeros(10,2);
          CurrentAnchor = Anchor(1:j*3,:);
          CurrentDistance = Distance(1:j*3,:);
          CurrentAngle = Angle(1:j*3,:);
          
         % tic;
         %   [TargetTemp3] = GPPADL(CurrentAnchor, CurrentDistance, CurrentAngle);
         %   LocationEstimation3(j,:) = TargetTemp3;
          %  ErrorProposedAlg3(j,1) = sqrt((Target(1,1) - TargetTemp3(1,1))^2 + (Target(1,2) - TargetTemp3(1,2))^2); 
         % RT_PPADL=toc;
         % Runningtime2(j,1) = RT_PPADL+PPADL;
          
         
          for t = 1:10
               q_x = 0;
               q_y = 0;
                for q = 1:j*3
                 for r = 1:R
                  if ismember(q,Anchor1) == 0
                           [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance, sigmaAngle, NN);
                  else                                                                                 
                            [distance_w,angle_w] = GetMeasurementForEachAnchor(Anchor(q,:), Target, sigmaDistance0, sigmaAngle0, NN);
                  end
                      Distance_w(1,:) = distance_w';
                      Angle_w(1,:) = angle_w';
                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance_w(1,:), Angle_w(1,:));
                   if t == 1 
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(1,2);
                   end
                 
                   if t > 1
                      Anchorx(r,1) =  Anchor_data(q,1) - LocationEstimation1(t-1,1);
                      Anchory(r,1) =  Anchor_data(q,2) - LocationEstimation1(t-1,2);
                   end
                 end
                  % Anchor_x(q,t) = mean(Anchorx);
                  % Anchor_y(q,t) = mean(Anchory);
                   if q<=0.3*j*3
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,8,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,8,'SQE');
                   else
                      [Anchorr1,q_data_x(1,q)] = quantize_clipping(Anchorx,2,'SQE');
                      [Anchorr2,q_data_y(1,q)] = quantize_clipping(Anchory,2,'SQE');
                   end
                  % Anchorr1 = Anchorr1';
                  % Anchorr2 = Anchorr2';
                   Anchor_quant_x(1,q) = mean(Anchorr1);
                   Anchor_quant_y(1,q) = mean(Anchorr2);
                    q_x = q_x + 1/q_data_x(1,q);
                    q_y = q_y + 1/q_data_y(1,q);
                   % Anchorx = Anchorx';
                    %Anchory = Anchory';

                      Anchor_data(q,:) = ProposedLocAlgorithm(Anchor(q,:), Distance_w(1,:), Angle_w(1,:));
               
                end
                if t == 1
                   for q = 1:j*3
                      LocationEstimation1(1,1) = LocationEstimation1(1,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                      LocationEstimation1(1,2) = LocationEstimation1(1,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);

                   end
                end
                if t > 1
                     LocationEstimation1(t,1) = LocationEstimation1(t-1,1);
                     LocationEstimation1(t,2) = LocationEstimation1(t-1,2);

                    for q = 1:j*3
                         LocationEstimation1(t,1) = LocationEstimation1(t,1)+ Anchor_quant_x(1,q) * ((1/q_data_x(1,q)) / q_x);
                         LocationEstimation1(t,2) = LocationEstimation1(t,2)+ Anchor_quant_y(1,q) * ((1/q_data_y(1,q)) / q_y);
                   %   LocationEstimation5(t,1) = LocationEstimation5(t,1)+ Anchorx1(1,q) * 1/(j*3);
                   %   LocationEstimation5(t,2) = LocationEstimation5(t,2)+ Anchory1(1,q) * 1/(j*3);
                    end
                end
          end
          RT_QPPL=toc;
          Runningtime1(j,1) = RT_QPPL;
           ErrorProposedAlg1(j,:) = sqrt((Target(1,1) - LocationEstimation1(t,1))^2 + (Target(1,2) - LocationEstimation1(t,2))^2);    
      end

     
         RT1(:,i) = Runningtime1(:,1);
         RT2(:,i) = Runningtime2(:,1);
         Error1(:,i) = ErrorProposedAlg1(:,1);
         Error2(:,i) = ErrorProposedAlg2(:,1);
         Error3(:,i) = ErrorProposedAlg3(:,1);
        % Error4(:,i) = ErrorProposedAlg4(:,1);
       % Error5(:,i) = ErrorProposedAlg5(:,1);
 
end

AnchorNum1 = (3:3:m);
AnchorNum2 = (3:3:m);


RT1 = RT1';
RTT1 = mean(RT1);
RT2 = RT2';
RTT2 = mean(RT2);
%Err2(1,1)=NaN;
figure(1);
plot((3:3:30),RTT1,'r-o','MarkerSize',8,'LineWidth',1.5)  
hold on
plot((3:3:30),Err2,'k-*','MarkerSize',8,'LineWidth',1.5)  
%hold on
%plot((3:3:30),RTT2,'b->','MarkerSize',8,'LineWidth',1.5)  

set(gca,'xtick',(3:3:30));
xlim([3, 30]);
%set(gca,'xtick',3:2:20);
legend('\fontsize{15} QPPL','\fontsize{15} HPPL');
xlabel({'Number of Anchors'},'FontSize',14);
ylabel({'Running time (seconds)'},'FontSize',14);
hold off

