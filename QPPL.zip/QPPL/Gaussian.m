function arr = Gaussian(n, mu, scale)

    % n: 生成随机数的数量
    % mu: 高斯分布的均值
    % scale: 高斯分布的标准差

    % 生成服从高斯分布的随机数
    arr = mu + scale * randn(1, n);

end